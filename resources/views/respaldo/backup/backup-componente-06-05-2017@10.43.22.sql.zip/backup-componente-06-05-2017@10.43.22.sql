-- # A Mysql Backup System
-- # Export created: 2017/05/06 on 10:43
-- # Database : componente
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `bancos`
DROP TABLE  IF EXISTS `bancos`;
CREATE TABLE `bancos` (
  `id_banco` int(3) NOT NULL AUTO_INCREMENT,
  `nombre` text NOT NULL,
  PRIMARY KEY (`id_banco`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `bancos` (`id_banco`, `nombre`) VALUES (1, ''), 
(2, 'Banco de Venezuela'), 
(3, 'Banco Mercantíl'), 
(4, 'Banco Banesco'), 
(5, 'Banco BFC'), 
(6, 'Banco Caroní'), 
(7, 'Bancaribe'), 
(8, 'Banco Bicentenario'), 
(9, 'Banco Venezolano de Crédito'), 
(10, 'Banco Provincial'), 
(11, 'BOD'), 
(12, 'Banco del Tesoro'), 
(13, 'Banco Agrovenezuela');

-- # Tabel structure for table `bitacora`
DROP TABLE  IF EXISTS `bitacora`;
CREATE TABLE `bitacora` (
  `id_mov` int(11) NOT NULL AUTO_INCREMENT,
  `responsable` text NOT NULL,
  `accion` text NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_mov`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;

INSERT INTO `bitacora` (`id_mov`, `responsable`, `accion`, `fecha`) VALUES (1, 'Osward', 'Inició sesión', '2017-02-10 19:01:03'), 
(2, 'Osward', 'Registró un nuevo cliente', '2017-02-10 19:01:41'), 
(3, 'Osward', 'Inició sesión', '2017-02-19 20:06:39'), 
(4, 'Osward', 'Inició sesión', '2017-02-20 21:20:21'), 
(5, 'Osward', 'Inició sesión', '2017-02-21 22:11:29'), 
(6, 'Osward', 'Creó una nueva categoria', '2017-02-22 00:22:54'), 
(7, 'Osward', 'Creó una nueva categoria', '2017-02-22 00:23:04'), 
(8, 'Osward', 'Creó una nueva categoria', '2017-02-22 00:23:17'), 
(9, 'Osward', 'Registró un nuevo producto', '2017-02-22 00:24:39'), 
(10, 'Osward', 'Registró un nuevo producto', '2017-02-22 00:26:27'), 
(11, 'Osward', 'Registró un nuevo producto', '2017-02-22 00:27:51'), 
(12, 'Osward', 'Registró un nuevo producto', '2017-02-22 00:29:06'), 
(13, 'Osward', 'Registró un nuevo producto', '2017-02-22 00:30:46'), 
(14, 'Osward', 'Registró un nuevo producto', '2017-02-22 00:31:56'), 
(15, 'Osward', 'Registró un nuevo producto', '2017-02-22 00:33:26'), 
(16, 'Osward', 'Registró un nuevo producto', '2017-02-22 00:34:35'), 
(17, 'Osward', 'Registró un nuevo producto', '2017-02-22 00:36:14'), 
(18, 'Maria', 'Inició sesión', '2017-02-22 12:52:59'), 
(19, 'Maria', 'Registró un nuevo cliente', '2017-02-22 12:54:53'), 
(20, 'Maria', 'Registró un nuevo cliente', '2017-02-22 12:56:48'), 
(21, 'Maria', 'Registró un nuevo cliente', '2017-02-22 12:58:00'), 
(22, 'Maria', 'Registró un nuevo cliente', '2017-02-22 12:58:53'), 
(23, 'Maria', 'Registró un nuevo cliente', '2017-02-22 13:00:19'), 
(24, 'Maria', 'Registró un nuevo cliente', '2017-02-22 13:01:59'), 
(25, 'Maria', 'Registró un nuevo cliente', '2017-02-22 13:03:17'), 
(26, 'Maria', 'Registró un nuevo cliente', '2017-02-22 13:05:05'), 
(27, 'Maria', 'Registró un nuevo cliente', '2017-02-22 13:06:39'), 
(28, 'Maria', 'Registró un nuevo proveedor', '2017-02-22 13:10:37'), 
(29, 'Maria', 'Registró un nuevo proveedor', '2017-02-22 13:12:17'), 
(30, 'Maria', 'Registró un nuevo proveedor', '2017-02-22 13:14:02'), 
(31, 'Maria', 'Registró un nuevo proveedor', '2017-02-22 13:15:31'), 
(32, 'Maria', 'Registró un nuevo proveedor', '2017-02-22 13:17:15'), 
(33, 'Maria', 'Registró un nuevo proveedor', '2017-02-22 13:18:53'), 
(34, 'Maria', 'Registró un nuevo proveedor', '2017-02-22 13:19:58'), 
(35, 'Maria', 'Registró un nuevo proveedor', '2017-02-22 13:20:51'), 
(36, 'Maria', 'Registró un nuevo proveedor', '2017-02-22 13:21:51'), 
(37, 'Maria', 'Registró un nuevo proveedor', '2017-02-22 13:22:35'), 
(38, 'Maria', 'Realizó una nueva compra', '2017-02-22 13:24:07'), 
(39, 'Osward', 'Inició sesión', '2017-02-22 13:24:32'), 
(40, 'Osward', 'Realizó una nueva compra', '2017-02-22 13:29:36'), 
(41, 'Osward', 'Realizó un presupuesto', '2017-02-22 13:31:00'), 
(42, 'Maria', 'Inició sesión', '2017-02-22 13:36:16'), 
(43, 'Osward', 'Inició sesión', '2017-02-22 13:36:50'), 
(44, 'Osward', 'Realizó una nueva compra', '2017-02-22 13:39:46'), 
(45, 'Osward', 'Realizó una nueva compra', '2017-02-22 13:40:29'), 
(46, 'Osward', 'Realizó un presupuesto', '2017-02-22 13:41:24'), 
(47, 'Osward', 'Realizó un presupuesto', '2017-02-22 13:43:19'), 
(48, 'Osward', 'Realizó un presupuesto', '2017-02-22 13:44:16'), 
(49, 'Osward', 'Realizó una nueva compra', '2017-02-22 13:48:57'), 
(50, 'Osward', 'Realizó una nueva compra', '2017-02-22 13:50:46'), 
(51, 'Osward', 'Realizó una nueva compra', '2017-02-22 13:56:09'), 
(52, 'Osward', 'Inició sesión', '2017-02-22 14:07:37'), 
(53, 'Osward', 'Registró un nuevo cliente', '2017-02-22 14:09:50'), 
(54, 'Osward', 'Realizó una nueva compra', '2017-02-22 14:13:10'), 
(55, 'Osward', 'Realizó un presupuesto', '2017-02-22 14:14:24'), 
(56, 'Maria', 'Inició sesión', '2017-02-22 14:20:54'), 
(57, 'Osward', 'Inició sesión', '2017-02-22 14:23:22'), 
(58, 'Osward', 'Inició sesión', '2017-03-12 21:21:54'), 
(59, 'Osward', 'Inició sesión', '2017-03-15 08:20:50'), 
(60, 'Osward', 'Inició sesión', '2017-03-15 08:39:11'), 
(61, 'Osward', 'Inició sesión', '2017-04-02 21:15:54'), 
(62, 'Osward', 'Inició sesión', '2017-04-03 18:37:18'), 
(63, 'Osward', 'Inició sesión', '2017-04-23 19:09:16'), 
(64, 'Osward', 'Inició sesión', '2017-05-06 22:07:42'), 
(65, 'Osward', 'Realizó una nueva compra', '2017-05-06 22:11:48');

-- # Tabel structure for table `categorias`
DROP TABLE  IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id_cat` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_cat`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `categorias` (`id_cat`, `nombre`, `descripcion`) VALUES (1, 'Ferretería', 'Todo lo relacionado'), 
(2, 'Químicos', 'Todo'), 
(3, 'Maderas', 'De todo tipo');

-- # Tabel structure for table `clientes`
DROP TABLE  IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `razon_social` text COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `clientes` (`id_cliente`, `rif`, `razon_social`, `telefono`, `email`, `direccion`, `status`) VALUES (1, 'J-20989357-0', 'Osward José', '0414-5435737', 'ojpr15@gmail.com', 'Cagua', 'activo'), 
(2, 'J-20989357-1', 'Gloriangel Rojas', '0244-3457667', 'Glori@gmail.com', 'Turmero, Paya', 'activo'), 
(3, 'J-26613711-0', 'Ferretería Fayad', '0243-4655580', 'webmaster@gandocam.com.ve', 'Cagua', 'activo'), 
(4, 'J-26735381-1', 'Distribuidora \"Los Rapiditos\" ', '0243-4653322', 'Rapid@gmail.com', 'Cagua', 'activo'), 
(5, 'J-25065787-0', 'Ferretería San Pedro', '0243-9753410', 'SanPedroferre@gmail.com', 'Corinsa, Cagua', 'activo'), 
(6, 'J-25880366-2', 'SumiServices C.A', '0244-3963572', 'SumiSvs@gmail.com', 'Cagua', 'activo'), 
(7, 'J-10759226-1', 'Ferre Útil', '0243-4655256', 'Utilservices@gmail.com', 'La Villa', 'activo'), 
(8, 'J-10457682-0', 'Ferretería La Villa', '0244-3952470', 'VillaFerre@gmail.com', 'La Villa, Estado Aragua', 'activo'), 
(9, 'J-25460341-0', 'Ferre Victoria', '0244-3964501', 'VictoriaF@gmail.com', 'La Victoria', 'activo'), 
(10, 'J-17835091-0', 'Ferretería 24 horas', '0243-4050347', 'Lavictoria24@gmail.com', 'La Victoria', 'activo'), 
(11, 'J-20989357-4', 'Grupo UPTA', '0244-3457665', 'upta@gmail.com', 'La Victoria', 'activo');

-- # Tabel structure for table `compras`
DROP TABLE  IF EXISTS `compras`;
CREATE TABLE `compras` (
  `cod_compra` int(15) NOT NULL,
  `id_prov` int(11) NOT NULL,
  `id_emp` int(10) NOT NULL,
  `fecha_actual` date NOT NULL,
  `forma_pago` enum('efectivo','deposito / transferencia','credito','') COLLATE utf8_spanish_ci NOT NULL,
  `banco` text COLLATE utf8_spanish_ci NOT NULL,
  `nro_cuenta` int(30) NOT NULL,
  `nro_comprobante` int(30) NOT NULL,
  `impuesto` int(10) NOT NULL,
  `subtot` int(10) NOT NULL,
  `tot` int(10) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cod_compra`),
  KEY `id_proveedor` (`id_prov`),
  KEY `id_emp` (`id_emp`),
  CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`id_prov`) REFERENCES `proveedores` (`id_prov`),
  CONSTRAINT `compras_ibfk_2` FOREIGN KEY (`id_emp`) REFERENCES `empleados` (`id_emp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `compras` (`cod_compra`, `id_prov`, `id_emp`, `fecha_actual`, `forma_pago`, `banco`, `nro_cuenta`, `nro_comprobante`, `impuesto`, `subtot`, `tot`, `status`) VALUES (1, 10, 2, '2017-02-22', 'efectivo', '', 0, 0, 0, 95800, 95800, 'activo'), 
(2, 8, 1, '2017-02-22', 'deposito / transferencia', 'Banco Banesco', 2147483647, 7832578, 0, 81460, 81460, 'activo'), 
(3, 5, 1, '2017-02-22', 'efectivo', '', 0, 0, 8567, 71395, 79962, 'activo'), 
(4, 7, 1, '2017-02-22', '', '', 0, 0, 37901, 315843, 353744, 'activo'), 
(5, 3, 1, '2017-02-22', 'efectivo', '', 0, 0, 52259, 435490, 487749, 'activo'), 
(6, 1, 1, '2017-02-22', 'deposito / transferencia', 'Banco Provincial', 2147483647, 72836283, 2208, 18400, 20608, 'activo'), 
(7, 1, 1, '2017-02-22', '', '', 0, 0, 1089984, 9083200, 10173184, 'activo'), 
(8, 10, 1, '2017-02-22', 'deposito / transferencia', 'Banco de Venezuela', 2147483647, 73467846, 44016, 366803, 410819, 'activo'), 
(9, 3, 1, '2017-05-06', 'efectivo', '', 0, 0, 16984, 130647, 147631, 'activo');

-- # Tabel structure for table `det_compra`
DROP TABLE  IF EXISTS `det_compra`;
CREATE TABLE `det_compra` (
  `cod_compra` int(15) NOT NULL,
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  KEY `cod_prod` (`cod_prod`),
  KEY `cod_compra` (`cod_compra`),
  CONSTRAINT `det_compra_ibfk_1` FOREIGN KEY (`cod_compra`) REFERENCES `compras` (`cod_compra`),
  CONSTRAINT `det_compra_ibfk_2` FOREIGN KEY (`cod_prod`) REFERENCES `productos` (`cod_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `det_compra` (`cod_compra`, `cod_prod`, `cantidad`, `precio`) VALUES (1, 'LLA08R5', 4, 14200), 
(1, 'DW44730', 8, 4875), 
(2, 'A010', 5, 12392), 
(2, 'DW44730', 4, 4875), 
(3, 'DW44730', 3, 4875), 
(3, 'BAL-36', 5, 11354), 
(4, '213FTAL', 7, 43549), 
(4, 'MP2883', 5, 2200), 
(5, '213FTAL', 10, 43549), 
(6, 'MP2883', 4, 2200), 
(6, 'M1100300', 3, 3200), 
(7, 'BAL-36', 800, 11354), 
(8, 'A010', 5, 12392), 
(8, '213FTAL', 7, 43549), 
(9, '213FTAL', 3, 43549);

-- # Tabel structure for table `det_presu`
DROP TABLE  IF EXISTS `det_presu`;
CREATE TABLE `det_presu` (
  `cod_presu` int(15) NOT NULL,
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  KEY `cod_prod` (`cod_prod`),
  KEY `cod_presu` (`cod_presu`),
  CONSTRAINT `det_presu_ibfk_1` FOREIGN KEY (`cod_presu`) REFERENCES `presupuestos` (`cod_presu`),
  CONSTRAINT `det_presu_ibfk_2` FOREIGN KEY (`cod_prod`) REFERENCES `productos` (`cod_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `det_presu` (`cod_presu`, `cod_prod`, `cantidad`, `precio`) VALUES (2, 'DW44730', 3, 4875), 
(2, 'BAL-36', 6, 11354), 
(4, '213FTAL', 50, 43549), 
(4, 'ST1270', 10, 6100), 
(6, 'A010', 5, 12392), 
(6, 'BAL-36', 2, 11354), 
(6, 'LLA08R5', 6, 14200), 
(8, 'MP2883', 5, 2200), 
(8, 'ST1270', 1, 6100), 
(10, '213FTAL', 12, 43549), 
(10, 'LLA08R5', 4, 14200);

-- # Tabel structure for table `det_venta`
DROP TABLE  IF EXISTS `det_venta`;
CREATE TABLE `det_venta` (
  `cod_venta` int(15) NOT NULL,
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  KEY `cod_prod` (`cod_prod`),
  KEY `cod_venta` (`cod_venta`),
  CONSTRAINT `det_venta_ibfk_1` FOREIGN KEY (`cod_venta`) REFERENCES `ventas` (`cod_venta`),
  CONSTRAINT `det_venta_ibfk_2` FOREIGN KEY (`cod_prod`) REFERENCES `productos` (`cod_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `det_venta` (`cod_venta`, `cod_prod`, `cantidad`, `precio`) VALUES (2, 'LLA08R5', 5, 14200), 
(4, '213FTAL', 5, 43549), 
(4, 'BAL-36', 3, 11354), 
(6, '213FTAL', 3, 43549), 
(6, 'LLA08R5', 3, 14200), 
(8, 'MP2883', 4, 2200), 
(8, '213FTAL', 3, 43549), 
(10, 'MP2883', 2, 2200), 
(10, 'ST1270', 6, 6100);

-- # Tabel structure for table `empleados`
DROP TABLE  IF EXISTS `empleados`;
CREATE TABLE `empleados` (
  `id_emp` int(11) NOT NULL AUTO_INCREMENT,
  `ci_usuario` int(10) NOT NULL,
  `primer_nombre` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `primer_apellido` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `username` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `rol` enum('Administrador','empleado','','') COLLATE utf8_spanish_ci NOT NULL,
  `pregunta` text COLLATE utf8_spanish_ci NOT NULL,
  `respuesta` text COLLATE utf8_spanish_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL DEFAULT 'activo',
  PRIMARY KEY (`id_emp`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `empleados` (`id_emp`, `ci_usuario`, `primer_nombre`, `primer_apellido`, `username`, `password`, `rol`, `pregunta`, `respuesta`, `status`) VALUES (1, 20989357, 'Osward', 'Pacheco', 'admin', '81dc9bdb52d04dc20036dbd8313ed055', 'Administrador', '¿Color?', 'Azul', 'activo'), 
(2, 10759226, 'Maria', 'Silva', 'maria', '263bce650e68ab4e23f28263760b9fa5', 'empleado', 'Como te llamas?', 'maria', 'activo');

-- # Tabel structure for table `presupuestos`
DROP TABLE  IF EXISTS `presupuestos`;
CREATE TABLE `presupuestos` (
  `cod_presu` int(15) NOT NULL,
  `id_cliente` int(15) NOT NULL,
  `id_emp` int(15) NOT NULL,
  `fecha_actual` date NOT NULL,
  `fecha_vencimiento` enum('5 Días','','','') COLLATE utf8_spanish_ci NOT NULL,
  `impuesto` int(15) NOT NULL,
  `descuento` int(15) NOT NULL,
  `subtot` int(15) NOT NULL,
  `tot` int(15) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cod_presu`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_emp` (`id_emp`),
  CONSTRAINT `presupuestos_ibfk_1` FOREIGN KEY (`id_emp`) REFERENCES `empleados` (`id_emp`),
  CONSTRAINT `presupuestos_ibfk_2` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `presupuestos` (`cod_presu`, `id_cliente`, `id_emp`, `fecha_actual`, `fecha_vencimiento`, `impuesto`, `descuento`, `subtot`, `tot`, `status`) VALUES (2, 1, 1, '2017-02-22', '5 Días', 0, 0, 82749, 82749, 'activo'), 
(4, 3, 1, '2017-02-22', '5 Días', 268614, 0, 2238450, 2507064, 'activo'), 
(6, 7, 1, '2017-02-22', '5 Días', 20384, 0, 169868, 190252, 'activo'), 
(8, 9, 1, '2017-02-22', '5 Días', 2052, 0, 17100, 19152, 'activo'), 
(10, 1, 1, '2017-02-22', '5 Días', 69527, 0, 579388, 648915, 'activo');

-- # Tabel structure for table `productos`
DROP TABLE  IF EXISTS `productos`;
CREATE TABLE `productos` (
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `modelo` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `peso` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `color` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `garantia` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `p_compra` int(10) NOT NULL,
  `p_venta` int(10) NOT NULL,
  `stock` int(10) NOT NULL,
  `stock_minimo` int(10) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  `procedencia` enum('nacional','internacional') COLLATE utf8_spanish_ci NOT NULL,
  `id_cat` int(11) NOT NULL,
  PRIMARY KEY (`cod_prod`),
  KEY `id_cat` (`id_cat`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_cat`) REFERENCES `categorias` (`id_cat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `productos` (`cod_prod`, `descripcion`, `modelo`, `peso`, `color`, `garantia`, `p_compra`, `p_venta`, `stock`, `stock_minimo`, `status`, `procedencia`, `id_cat`) VALUES ('213FTAL', 'Taladro de impacto', 'Blackwell', '.', '.', '.', 43549, 43549, 1016, 100, 'activo', 'internacional', 1), 
('A010', 'Maceta corta mango de fibra de', 'No identificado', '.', '.', '.', 12392, 19250, 1010, 100, 'activo', 'nacional', 1), 
('BAL-36', 'Balastro Electronico Plano Par', 'Para
Lamparas 1 X 40 Wattios', '.', '.', '.', 11354, 11354, 1802, 100, 'activo', 'nacional', 1), 
('DW44730', 'Disco abrasivo corte concreto', 'Dewalt 7\"x1/8\"x7/8\"', '0,15', 'Negro', '.', 4875, 5960, 1015, 100, 'activo', 'internacional', 1), 
('FIT-LC', 'LLave de cadena', '9\" Borny', '.', '.', '.', 8200, 14320, 2000, 100, 'activo', 'internacional', 1), 
('LLA08R5', 'Llave ajustable para tubo', 'Stillson de 8\"', '.', '.', '1 AÑO', 14200, 14200, 996, 100, 'activo', 'internacional', 1), 
('M1100300', 'Cabo De Madera Para Palas', 'Flync', '.', '.', '.', 3200, 5300, 1003, 100, 'activo', 'internacional', 3), 
('MP2883', 'Conector hembra', '1/4\"', '.', '.', '.', 2200, 2200, 2303, 100, 'activo', 'nacional', 1), 
('ST1270', 'Lubricante blanco para herrami', 'Glassy', '.', '.', '.', 6100, 6100, 1994, 100, 'activo', 'internacional', 1);

-- # Tabel structure for table `proveedores`
DROP TABLE  IF EXISTS `proveedores`;
CREATE TABLE `proveedores` (
  `id_prov` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `razon_social` text COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_prov`),
  UNIQUE KEY `rif` (`rif`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `proveedores` (`id_prov`, `rif`, `razon_social`, `telefono`, `email`, `direccion`, `status`) VALUES (1, 'J-17835091-0', 'Ferretería 24 horas	', '0243-4050347', 'Ferre24@gmail.com', 'La Victoria', 'activo'), 
(2, 'J-25460341-0', 'Ferre Victoria', '0244-3964501', 'VictoriaFerre@gmail.com', 'La Victoria', 'activo'), 
(3, 'J-10457682-0', 'Ferretería La Villa', '0244-3952470', 'VillaFerre@gmail.com', 'La Villa, Estado Aragua', 'activo'), 
(4, 'J-10759226-1', 'Ferre Útil', '0243-4655256', 'utilferreteriavilla@gmail.com', 'La Villa', 'activo'), 
(5, 'J-25880366-2', 'SumiServices C.A', '0244-3963572', 'SumiServices@gmail.com', 'Cagua', 'activo'), 
(6, 'J-25065787-0', 'Ferretería San Pedro', '0243-9753410', 'SanPedro@gmail.com', 'Corinsa, Cagua', 'activo'), 
(7, 'J-26735381-1', 'Distribuidora \"Los Rapiditos\"', '0243-4653322', 'Rapid@gmail.com', 'Cagua', 'activo'), 
(8, 'J-26613711-0', 'Ferretería Fayad', '0243-4655580', 'FayadFerre@gmail.com', 'Cagua', 'activo'), 
(9, 'J-20989357-1', 'Gloriangel Rojas', '0244-3457667', 'Glori@gmail.com', 'Turmero, Paya', 'activo'), 
(10, 'J-20989357-0', 'Osward José	', '0244-3962442', 'ojpr15@gmail.com', 'Cagua, La Ciudad', 'activo');

-- # Tabel structure for table `utilidades`
DROP TABLE  IF EXISTS `utilidades`;
CREATE TABLE `utilidades` (
  `impuesto` int(4) NOT NULL,
  `ven_presu` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `utilidades` (`impuesto`, `ven_presu`) VALUES (13, 0);

-- # Tabel structure for table `ventas`
DROP TABLE  IF EXISTS `ventas`;
CREATE TABLE `ventas` (
  `cod_venta` int(15) NOT NULL,
  `id_cliente` int(15) NOT NULL,
  `id_emp` int(15) NOT NULL,
  `fecha_actual` date NOT NULL,
  `forma_pago` enum('efectivo','deposito / transferencia','credito','') COLLATE utf8_spanish_ci NOT NULL,
  `banco` text COLLATE utf8_spanish_ci NOT NULL,
  `nro_cuenta` int(30) NOT NULL,
  `nro_comprobante` int(30) NOT NULL,
  `impuesto` int(15) NOT NULL,
  `descuento` int(15) NOT NULL,
  `subtot` int(15) NOT NULL,
  `tot` int(15) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cod_venta`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_emp` (`id_emp`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`id_emp`) REFERENCES `empleados` (`id_emp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `ventas` (`cod_venta`, `id_cliente`, `id_emp`, `fecha_actual`, `forma_pago`, `banco`, `nro_cuenta`, `nro_comprobante`, `impuesto`, `descuento`, `subtot`, `tot`, `status`) VALUES (2, 1, 1, '2017-02-22', 'efectivo', '', 0, 0, 8520, 0, 71000, 79520, 'activo'), 
(4, 3, 1, '2017-02-22', 'deposito / transferencia', 'Banco de Venezuela', 2147483647, 24782646, 30217, 0, 251807, 282024, 'activo'), 
(6, 10, 1, '2017-02-22', 'deposito / transferencia', 'Banco Caroní', 2147483647, 892379823, 20790, 0, 173247, 194037, 'activo'), 
(8, 3, 1, '2017-02-22', 'deposito / transferencia', 'Banco de Venezuela', 2147483647, 7862672, 16734, 0, 139447, 156181, 'activo'), 
(10, 10, 1, '2017-02-22', '', '', 0, 0, 4920, 0, 41000, 45920, 'activo');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
