-- # A Mysql Backup System
-- # Export created: 2017/11/15 on 08:59
-- # Database : zogan
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `almac_repues`
DROP TABLE  IF EXISTS `almac_repues`;
CREATE TABLE `almac_repues` (
  `almacen_id` int(10) unsigned NOT NULL,
  `repuesto_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `almac_repues_almacen_id_foreign` (`almacen_id`),
  KEY `almac_repues_repuesto_id_foreign` (`repuesto_id`),
  CONSTRAINT `almac_repues_almacen_id_foreign` FOREIGN KEY (`almacen_id`) REFERENCES `almacenes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `almac_repues_repuesto_id_foreign` FOREIGN KEY (`repuesto_id`) REFERENCES `repuestos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `almacenes`
DROP TABLE  IF EXISTS `almacenes`;
CREATE TABLE `almacenes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `seccion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cubiculo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `analis_asegu`
DROP TABLE  IF EXISTS `analis_asegu`;
CREATE TABLE `analis_asegu` (
  `analista_id` int(10) unsigned NOT NULL,
  `aseguradora_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `analis_asegu_analista_id_foreign` (`analista_id`),
  KEY `analis_asegu_aseguradora_id_foreign` (`aseguradora_id`),
  CONSTRAINT `analis_asegu_analista_id_foreign` FOREIGN KEY (`analista_id`) REFERENCES `analistas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `analis_asegu_aseguradora_id_foreign` FOREIGN KEY (`aseguradora_id`) REFERENCES `aseguradoras` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `analis_asegu` (`analista_id`, `aseguradora_id`, `created_at`, `updated_at`) VALUES (1, 1, '2017-10-15 22:02:55', '2017-10-15 22:02:55'), 
(2, 1, '2017-10-18 14:31:55', '2017-10-18 14:31:55'), 
(3, 1, '2017-10-18 14:37:29', '2017-10-18 14:37:29');

-- # Tabel structure for table `analistas`
DROP TABLE  IF EXISTS `analistas`;
CREATE TABLE `analistas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rif` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `analistas` (`id`, `rif`, `nombre`, `apellido`, `celular`, `telefono`, `email`, `status`, `created_at`, `updated_at`) VALUES (1, 'J-20989357-0', 'OSWARD', 'PACHECO', '0424-3224353', '0212-4065544', 'OSWARDP_94@HOTMAIL.COM', 'activo', '2017-10-15 22:02:55', '2017-10-18 14:40:24'), 
(2, 'J-20989357-9', 'PEDRO', 'PEREZ', '0424-3224354', '0212-4065543', 'PEDRO@GMAIL.COM', 'inactivo', '2017-10-18 14:31:54', '2017-10-18 14:38:23'), 
(3, 'J-20989357-0', 'TYYT', 'DFFVDD', '0424-3224354', '0424-3513322', 'TTYRT@GMAIL.COM', 'inactivo', '2017-10-18 14:37:28', '2017-10-18 14:37:28');

-- # Tabel structure for table `areas`
DROP TABLE  IF EXISTS `areas`;
CREATE TABLE `areas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `areas` (`id`, `codigo`, `descripcion`, `status`, `created_at`, `updated_at`) VALUES (1, 'A00001', 'PINTURAS', 'activo', '2017-10-16 00:19:14', '2017-10-16 00:27:04');

-- # Tabel structure for table `aseguradoras`
DROP TABLE  IF EXISTS `aseguradoras`;
CREATE TABLE `aseguradoras` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rif` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `denominacion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `aseguradoras` (`id`, `rif`, `denominacion`, `telefono`, `email`, `status`, `created_at`, `updated_at`) VALUES (1, 'J-20989357-0', 'SEGUROS CARACAS, S.A', '0212-4065543', 'SEGUROSCARACAS@GMAIL.COM', 'inactivo', '2017-10-15 22:01:54', '2017-10-21 04:20:31'), 
(2, 'J-20989357-0', 'KJFRJKF', '0424-3513322', 'OJPR15@GMAIL.COM', 'inactivo', '2017-10-25 05:00:03', '2017-10-25 05:00:03'), 
(3, 'J-20989357-1', 'SEGUROS CARACAS S.A', '0212-4065544', 'SEGUROSCARACAS@GMAIL.COM', 'activo', '2017-10-25 05:03:47', '2017-10-25 05:03:47'), 
(4, 'J-20989357-2', 'EJFBEOBF', '0212-4065544', 'OSWARDP_94@HOTMAIL.COM', 'activo', '2017-10-25 13:55:04', '2017-10-25 13:55:04');

-- # Tabel structure for table `ayudantes`
DROP TABLE  IF EXISTS `ayudantes`;
CREATE TABLE `ayudantes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ayudantes` (`id`, `cedula`, `nombre`, `apellido`, `telefono`, `email`, `direccion`, `status`, `created_at`, `updated_at`) VALUES (1, 'V-20989357', 'PEDRO', 'RAMIREZ', '0424-3513322', 'OJPR15@GMAIL.COM', 'CAGUA', 'activo', '2017-10-13 02:57:53', '2017-10-13 03:00:42'), 
(2, 'V-20989353', 'ROBERTO', 'PEREZ', '0424-2345434', 'ROBERTP@GMAIL.COM', 'CAGUA', 'activo', '2017-10-15 22:07:59', '2017-10-15 22:07:59');

-- # Tabel structure for table `citas`
DROP TABLE  IF EXISTS `citas`;
CREATE TABLE `citas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reparacion_id` int(10) unsigned NOT NULL,
  `selec_dia` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `citas_reparacion_id_foreign` (`reparacion_id`),
  CONSTRAINT `citas_reparacion_id_foreign` FOREIGN KEY (`reparacion_id`) REFERENCES `reparaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `citas` (`id`, `reparacion_id`, `selec_dia`, `created_at`, `updated_at`) VALUES (1, 1, '2017-10-28', '2017-10-18 13:14:26', '2017-10-18 13:14:26'), 
(2, 1, '2017-10-27', '2017-10-25 15:19:03', '2017-10-25 15:19:03');

-- # Tabel structure for table `corre_asegu`
DROP TABLE  IF EXISTS `corre_asegu`;
CREATE TABLE `corre_asegu` (
  `corredor_id` int(10) unsigned NOT NULL,
  `aseguradora_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `corre_asegu_corredor_id_foreign` (`corredor_id`),
  KEY `corre_asegu_aseguradora_id_foreign` (`aseguradora_id`),
  CONSTRAINT `corre_asegu_aseguradora_id_foreign` FOREIGN KEY (`aseguradora_id`) REFERENCES `aseguradoras` (`id`) ON DELETE CASCADE,
  CONSTRAINT `corre_asegu_corredor_id_foreign` FOREIGN KEY (`corredor_id`) REFERENCES `corredores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `corre_asegu` (`corredor_id`, `aseguradora_id`, `created_at`, `updated_at`) VALUES (1, 1, '2017-10-15 22:05:47', '2017-10-15 22:05:47');

-- # Tabel structure for table `corredores`
DROP TABLE  IF EXISTS `corredores`;
CREATE TABLE `corredores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `corredores` (`id`, `cedula`, `nombre`, `apellido`, `celular`, `telefono`, `email`, `status`, `created_at`, `updated_at`) VALUES (1, 'J-10759226-4', 'ZULEIMA', 'REQUENA', '0426-4350796', '0212-4065333', 'ZULEIMA@GMAIL.COM', 'activo', '2017-10-15 22:05:46', '2017-10-15 22:05:46');

-- # Tabel structure for table `facturaciones`
DROP TABLE  IF EXISTS `facturaciones`;
CREATE TABLE `facturaciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reparacion_id` int(10) unsigned NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `forma_pago` enum('efectivo','deposito / transferencia') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nro_cuenta` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nro_comprobante` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `impuesto` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtot` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facturaciones_reparacion_id_foreign` (`reparacion_id`),
  CONSTRAINT `facturaciones_reparacion_id_foreign` FOREIGN KEY (`reparacion_id`) REFERENCES `reparaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `image_recs`
DROP TABLE  IF EXISTS `image_recs`;
CREATE TABLE `image_recs` (
  `imagen_id` int(10) unsigned NOT NULL,
  `recepcion_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `image_recs_imagen_id_foreign` (`imagen_id`),
  KEY `image_recs_recepcion_id_foreign` (`recepcion_id`),
  CONSTRAINT `image_recs_imagen_id_foreign` FOREIGN KEY (`imagen_id`) REFERENCES `imagenes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `image_recs_recepcion_id_foreign` FOREIGN KEY (`recepcion_id`) REFERENCES `recepciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `image_recs` (`imagen_id`, `recepcion_id`, `created_at`, `updated_at`) VALUES (1, 1, '2017-10-15 22:21:43', '2017-10-15 22:21:43'), 
(2, 1, '2017-10-15 22:21:44', '2017-10-15 22:21:44'), 
(3, 1, '2017-10-15 22:21:44', '2017-10-15 22:21:44'), 
(4, 1, '2017-10-15 22:21:45', '2017-10-15 22:21:45'), 
(5, 1, '2017-10-15 22:21:45', '2017-10-15 22:21:45'), 
(6, 1, '2017-10-15 22:21:45', '2017-10-15 22:21:45');

-- # Tabel structure for table `image_reps`
DROP TABLE  IF EXISTS `image_reps`;
CREATE TABLE `image_reps` (
  `imagen_id` int(10) unsigned NOT NULL,
  `repuesto_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `image_reps_imagen_id_foreign` (`imagen_id`),
  KEY `image_reps_repuesto_id_foreign` (`repuesto_id`),
  CONSTRAINT `image_reps_imagen_id_foreign` FOREIGN KEY (`imagen_id`) REFERENCES `imagenes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `image_reps_repuesto_id_foreign` FOREIGN KEY (`repuesto_id`) REFERENCES `repuestos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `image_revs`
DROP TABLE  IF EXISTS `image_revs`;
CREATE TABLE `image_revs` (
  `imagen_id` int(10) unsigned NOT NULL,
  `revision_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `image_revs_imagen_id_foreign` (`imagen_id`),
  KEY `image_revs_revision_id_foreign` (`revision_id`),
  CONSTRAINT `image_revs_imagen_id_foreign` FOREIGN KEY (`imagen_id`) REFERENCES `imagenes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `image_revs_revision_id_foreign` FOREIGN KEY (`revision_id`) REFERENCES `revisiones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `image_revs` (`imagen_id`, `revision_id`, `created_at`, `updated_at`) VALUES (7, 1, '2017-10-15 22:22:58', '2017-10-15 22:22:58'), 
(8, 1, '2017-10-15 22:22:58', '2017-10-15 22:22:58'), 
(9, 1, '2017-10-15 22:22:59', '2017-10-15 22:22:59'), 
(10, 1, '2017-10-15 22:22:59', '2017-10-15 22:22:59'), 
(11, 1, '2017-10-15 22:22:59', '2017-10-15 22:22:59'), 
(12, 1, '2017-10-15 22:22:59', '2017-10-15 22:22:59'), 
(13, 1, '2017-10-15 22:22:59', '2017-10-15 22:22:59'), 
(14, 1, '2017-10-15 22:23:00', '2017-10-15 22:23:00'), 
(15, 2, '2017-10-15 22:24:38', '2017-10-15 22:24:38'), 
(16, 2, '2017-10-15 22:24:38', '2017-10-15 22:24:38'), 
(17, 2, '2017-10-15 22:24:39', '2017-10-15 22:24:39'), 
(18, 2, '2017-10-15 22:24:39', '2017-10-15 22:24:39'), 
(19, 2, '2017-10-15 22:24:39', '2017-10-15 22:24:39'), 
(20, 3, '2017-10-16 01:10:55', '2017-10-16 01:10:55'), 
(21, 3, '2017-10-16 01:10:56', '2017-10-16 01:10:56'), 
(22, 3, '2017-10-16 01:10:56', '2017-10-16 01:10:56'), 
(23, 3, '2017-10-16 01:10:56', '2017-10-16 01:10:56'), 
(24, 3, '2017-10-16 01:10:56', '2017-10-16 01:10:56');

-- # Tabel structure for table `imagenes`
DROP TABLE  IF EXISTS `imagenes`;
CREATE TABLE `imagenes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `imagenes` (`id`, `nombre`, `created_at`, `updated_at`) VALUES (1, 'cvGjT.jpg', '2017-10-15 22:21:43', '2017-10-15 22:21:43'), 
(2, '0yeFU.jpg', '2017-10-15 22:21:43', '2017-10-15 22:21:43'), 
(3, 'JKzlN.jpg', '2017-10-15 22:21:44', '2017-10-15 22:21:44'), 
(4, '2oUZP.jpg', '2017-10-15 22:21:44', '2017-10-15 22:21:44'), 
(5, 'dgSEi.jpg', '2017-10-15 22:21:45', '2017-10-15 22:21:45'), 
(6, 'w985n.jpg', '2017-10-15 22:21:45', '2017-10-15 22:21:45'), 
(7, 'QfLrj.jpg', '2017-10-15 22:22:58', '2017-10-15 22:22:58'), 
(8, 'EV8pD.jpg', '2017-10-15 22:22:58', '2017-10-15 22:22:58'), 
(9, 'q5VsM.jpg', '2017-10-15 22:22:58', '2017-10-15 22:22:58'), 
(10, 'IeOib.jpg', '2017-10-15 22:22:59', '2017-10-15 22:22:59'), 
(11, 'exaGm.jpg', '2017-10-15 22:22:59', '2017-10-15 22:22:59'), 
(12, 'CU7XF.jpg', '2017-10-15 22:22:59', '2017-10-15 22:22:59'), 
(13, 'QvZI6.jpg', '2017-10-15 22:22:59', '2017-10-15 22:22:59'), 
(14, 'h8vMi.jpg', '2017-10-15 22:22:59', '2017-10-15 22:22:59'), 
(15, 'TvqPJ.jpg', '2017-10-15 22:24:37', '2017-10-15 22:24:37'), 
(16, 'QEvWu.jpg', '2017-10-15 22:24:38', '2017-10-15 22:24:38'), 
(17, 'XpuqU.jpg', '2017-10-15 22:24:38', '2017-10-15 22:24:38'), 
(18, 'o7fXh.jpg', '2017-10-15 22:24:39', '2017-10-15 22:24:39'), 
(19, '085J8.jpg', '2017-10-15 22:24:39', '2017-10-15 22:24:39'), 
(20, 'urC5Q.jpg', '2017-10-16 01:10:55', '2017-10-16 01:10:55'), 
(21, 'Ajoo8.jpg', '2017-10-16 01:10:55', '2017-10-16 01:10:55'), 
(22, 'cR0wh.jpg', '2017-10-16 01:10:56', '2017-10-16 01:10:56'), 
(23, 'hwy6N.jpg', '2017-10-16 01:10:56', '2017-10-16 01:10:56'), 
(24, 'lk5KP.jpg', '2017-10-16 01:10:56', '2017-10-16 01:10:56');

-- # Tabel structure for table `mater_almac`
DROP TABLE  IF EXISTS `mater_almac`;
CREATE TABLE `mater_almac` (
  `material_id` int(10) unsigned NOT NULL,
  `almacen_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `mater_almac_material_id_foreign` (`material_id`),
  KEY `mater_almac_almacen_id_foreign` (`almacen_id`),
  CONSTRAINT `mater_almac_almacen_id_foreign` FOREIGN KEY (`almacen_id`) REFERENCES `almacenes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mater_almac_material_id_foreign` FOREIGN KEY (`material_id`) REFERENCES `materiales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `materiales`
DROP TABLE  IF EXISTS `materiales`;
CREATE TABLE `materiales` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cantidad` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marca` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modelo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `costo` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoria` enum('pintura','latoneria') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `migrations`
DROP TABLE  IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1, '2014_10_12_000000_create_users_table', 1), 
(2, '2014_10_12_100000_create_password_resets_table', 1), 
(3, '2017_05_08_121909_create_propietarios_table', 1), 
(4, '2017_05_08_121955_create_vehiculos_table', 1), 
(5, '2017_05_08_122044_create_repuestos_table', 1), 
(6, '2017_05_08_122108_create_aseguradoras_table', 1), 
(7, '2017_05_08_122136_create_corredores_table', 1), 
(8, '2017_05_08_123130_create_operarios_table', 1), 
(9, '2017_05_14_010822_create_analistas_table', 1), 
(10, '2017_05_14_060415_create_polizas_table', 1), 
(11, '2017_05_14_154409_create_reparaciones_table', 1), 
(12, '2017_05_14_154536_create_citas_table', 1), 
(13, '2017_05_14_154911_create_revisiones_table', 1), 
(14, '2017_05_14_154947_create_imagenes_table', 1), 
(15, '2017_05_14_155158_create_image_revs_table', 1), 
(16, '2017_05_14_214600_create_almacenes_table', 1), 
(17, '2017_05_16_132914_create_recepciones_table', 1), 
(18, '2017_05_16_133850_create_image_recs_table', 1), 
(19, '2017_05_19_005953_create_image_reps_table', 1), 
(20, '2017_05_19_012622_create_materiales_table', 1), 
(21, '2017_05_23_050024_create_corre_asegu_table', 1), 
(22, '2017_05_23_052606_create_facturaciones_table', 1), 
(23, '2017_05_23_054831_create_almac_repues_table', 1), 
(24, '2017_05_23_060310_create_mater_almac_table', 1), 
(25, '2017_06_20_011033_create_analis_asegu_table', 1), 
(26, '2017_07_01_163148_create_repue_repar_table', 1), 
(27, '2017_10_13_023718_create_ayudantes_table', 2), 
(28, '2017_10_15_212721_create_areas_table', 3);

-- # Tabel structure for table `operarios`
DROP TABLE  IF EXISTS `operarios`;
CREATE TABLE `operarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('latonero','pintor') COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `operarios` (`id`, `cedula`, `nombre`, `apellido`, `telefono`, `email`, `tipo`, `direccion`, `status`, `created_at`, `updated_at`) VALUES (1, 'V-20989357', 'OSWARD', 'PACHECO', '0424-3513322', 'OJPR15@GMAIL.COM', 'latonero', 'CAGUA', 'activo', '2017-10-15 22:06:27', '2017-10-15 22:06:27'), 
(2, 'V-10759226', 'SIMÓN', 'BARRERA', '0412-4567802', 'SIMON@GMAIL.COM', 'pintor', 'VALENCIA', 'activo', '2017-10-15 22:07:14', '2017-10-15 22:07:14'), 
(3, 'V-20989359', 'REWFR', 'FRWEF', '0414-5435737', 'OJPR15@GMAIL.COM', 'latonero', 'CAGUA
CAGUA', 'activo', '2017-10-25 15:03:58', '2017-10-25 15:03:58');

-- # Tabel structure for table `password_resets`
DROP TABLE  IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `polizas`
DROP TABLE  IF EXISTS `polizas`;
CREATE TABLE `polizas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aseguradora_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `polizas_aseguradora_id_foreign` (`aseguradora_id`),
  CONSTRAINT `polizas_aseguradora_id_foreign` FOREIGN KEY (`aseguradora_id`) REFERENCES `aseguradoras` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `polizas` (`id`, `numero`, `aseguradora_id`, `created_at`, `updated_at`) VALUES (1, '45-45-457336', 1, '2017-10-15 22:10:39', '2017-10-15 22:10:39');

-- # Tabel structure for table `propietarios`
DROP TABLE  IF EXISTS `propietarios`;
CREATE TABLE `propietarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rif` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre_completo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `propietarios` (`id`, `rif`, `nombre_completo`, `telefono`, `email`, `created_at`, `updated_at`) VALUES (1, 'V-20989357', 'PACHECO REQUENA OSWARD JOSÉ', '0424-3513322', 'OJPR15@GMAIL.COM', '2017-10-15 22:10:39', '2017-10-15 22:10:39');

-- # Tabel structure for table `recepciones`
DROP TABLE  IF EXISTS `recepciones`;
CREATE TABLE `recepciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `chofer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tlf_chofer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productor` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recibe` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `kilometraje` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `combustible` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observacion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recepciones_vehiculo_id_foreign` (`vehiculo_id`),
  CONSTRAINT `recepciones_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `recepciones` (`id`, `vehiculo_id`, `chofer`, `tlf_chofer`, `productor`, `recibe`, `fecha`, `kilometraje`, `combustible`, `observacion`, `created_at`, `updated_at`) VALUES (1, 1, 'RAMÓN PÉREZ', '0424-1223323', 'SEGUROS CARACAS', 'HERNÁN', '2017-10-15', 320000, '20 LITROS', 'NINGUNO', '2017-10-15 22:21:43', '2017-10-15 22:21:43');

-- # Tabel structure for table `reparaciones`
DROP TABLE  IF EXISTS `reparaciones`;
CREATE TABLE `reparaciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned NOT NULL,
  `propietario_id` int(10) unsigned NOT NULL,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `analista_id` int(10) unsigned NOT NULL,
  `latonero_id` int(10) unsigned NOT NULL,
  `pintor_id` int(10) unsigned NOT NULL,
  `fecha_ocu` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `num_certificado` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nro_siniestro` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notas` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mano_obra` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `depreciacion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mecanica_otros` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtotal_mo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `otros_gastos` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tot_manobra` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_repues` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `depre_repues` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_accesorios` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `depre_acce` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `repues_taller` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `manejo_repues` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deduccion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_prepago` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `iva` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deducible_p` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtotal` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `islr` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordenes_repues` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `repues_otros` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `depreciacion_two` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accesorios` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `depreciacion_nega` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_ordenes_acc` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto_asegu` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto_final` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion_daños` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipos_daños` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `selec_repues` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_dispo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo','','') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reparaciones_propietario_id_foreign` (`propietario_id`),
  KEY `reparaciones_vehiculo_id_foreign` (`vehiculo_id`),
  KEY `reparaciones_analista_id_foreign` (`analista_id`),
  KEY `reparaciones_latonero_id_foreign` (`latonero_id`),
  KEY `reparaciones_pintor_id_foreign` (`pintor_id`),
  CONSTRAINT `reparaciones_analista_id_foreign` FOREIGN KEY (`analista_id`) REFERENCES `analistas` (`id`),
  CONSTRAINT `reparaciones_latonero_id_foreign` FOREIGN KEY (`latonero_id`) REFERENCES `operarios` (`id`),
  CONSTRAINT `reparaciones_pintor_id_foreign` FOREIGN KEY (`pintor_id`) REFERENCES `operarios` (`id`),
  CONSTRAINT `reparaciones_propietario_id_foreign` FOREIGN KEY (`propietario_id`) REFERENCES `propietarios` (`id`),
  CONSTRAINT `reparaciones_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `reparaciones` (`id`, `usuario_id`, `propietario_id`, `vehiculo_id`, `analista_id`, `latonero_id`, `pintor_id`, `fecha_ocu`, `num_certificado`, `nro_siniestro`, `notas`, `mano_obra`, `depreciacion`, `mecanica_otros`, `subtotal_mo`, `otros_gastos`, `tot_manobra`, `total_repues`, `depre_repues`, `total_accesorios`, `depre_acce`, `repues_taller`, `manejo_repues`, `deduccion`, `desc_prepago`, `monto`, `iva`, `deducible_p`, `subtotal`, `islr`, `ordenes_repues`, `repues_otros`, `depreciacion_two`, `accesorios`, `depreciacion_nega`, `total_ordenes_acc`, `monto_asegu`, `monto_final`, `descripcion_daños`, `tipos_daños`, `selec_repues`, `no_dispo`, `status`, `created_at`, `updated_at`) VALUES (1, 1, 1, 1, 1, 1, 2, '23-02-2015', 435345, '43-67798643', 'NINGUNA', 333, 8988, 898, 988, 8, 8, 99, 89, 898, 9, 989, 898, 98, 988, 8, 898, 8, 98, 8, 8, 89, 9, 8, 988, 98, 89, 8, 'JHFDOHDOJVDJOIVH
REGREGIOREJG
ERGERGOIHR', 'WEJFHUOWEHF
EFUIWEHFOWEHF
UIEFHWEHF', 'UIHREFREOFEJFRFR', 'ROFHREOFHOREF', 'activo', '2017-10-15 22:10:39', '2017-10-15 22:10:39');

-- # Tabel structure for table `repue_repar`
DROP TABLE  IF EXISTS `repue_repar`;
CREATE TABLE `repue_repar` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reparacion_id` int(10) unsigned NOT NULL,
  `repuesto_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `repue_repar_reparacion_id_foreign` (`reparacion_id`),
  KEY `repue_repar_repuesto_id_foreign` (`repuesto_id`),
  CONSTRAINT `repue_repar_reparacion_id_foreign` FOREIGN KEY (`reparacion_id`) REFERENCES `reparaciones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `repue_repar_repuesto_id_foreign` FOREIGN KEY (`repuesto_id`) REFERENCES `repuestos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `repuestos`
DROP TABLE  IF EXISTS `repuestos`;
CREATE TABLE `repuestos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cantidad` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marca` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modelo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `repuestos` (`id`, `codigo`, `descripcion`, `cantidad`, `marca`, `modelo`, `area`, `status`, `created_at`, `updated_at`) VALUES (1, 'D4D4', '4F4F4', 'RFR', 'FRFR', 'RFR', 'PINTURAS', 'activo', '2017-10-16 01:04:34', '2017-10-16 01:51:08');

-- # Tabel structure for table `revisiones`
DROP TABLE  IF EXISTS `revisiones`;
CREATE TABLE `revisiones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `encargado_entrega` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encargado_recibe` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avances` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `revisiones_vehiculo_id_foreign` (`vehiculo_id`),
  CONSTRAINT `revisiones_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `revisiones` (`id`, `vehiculo_id`, `encargado_entrega`, `encargado_recibe`, `avances`, `tipo`, `fecha`, `created_at`, `updated_at`) VALUES (1, 1, 1, 2, 'NINGUNO', 'DESARMADO', '2017-10-16', '2017-10-15 22:22:58', '2017-10-15 22:22:58'), 
(2, 1, 2, 1, 'JEFHJRHJC', 'LATONERIA', '2017-10-17', '2017-10-15 22:24:37', '2017-10-15 22:24:37'), 
(3, 1, 'PEDRO', 'ROBERTO', 'RGTGTRG', 'PREPARACION', '2017-10-17', '2017-10-16 01:10:55', '2017-10-16 01:10:55');

-- # Tabel structure for table `users`
DROP TABLE  IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` enum('Administrador','Empleado','','') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo','','') COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `rol`, `status`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES (1, 'Osward José', 'ojpr15@gmail.com', 'Administrador', 'activo', '$2y$10$zNz4ormTE9.DMJaxgYEt9uh6nvH0RyAqi1x09VmKRI5tQWPPSMAmW', 'rDLl0f1pwBnmr029ejjHU1HO71uT68yP8u7QpumJGCL3ywnci78RlgKhcaPe', '2017-10-10 03:50:30', '2017-10-10 03:50:30'), 
(2, 'frforhfor', 'OswardP_94@hotmail.com', 'Administrador', 'inactivo', '$2y$10$8v3f0pcwnyRg4xmSyqiRXeQzfgTFSUPaWk8is5hEYsVX52aQvpqr6', 'yeyKKfILN6yoxYacvbuJKTXgxqjvww2BbnIlRp3fRRGBq7DsgOHMx4gAX2Sg', '2017-10-17 04:53:54', '2017-10-17 04:53:54'), 
(3, 'JOSE', 'josenrb@hotmail.com', 'Empleado', 'inactivo', '$2y$10$RRDzUHNjukFVyCMnyGlmEuK6MLuHVPxrLDiPfF5dNuomSYI8Dslpq', '', '2017-10-17 04:57:56', '2017-10-17 04:57:56'), 
(4, 'JOSE', 'josenddrb@hotmail.com', 'Administrador', 'inactivo', '$2y$10$RgPL2g7nu6Td4.Jf70AxaupKJjAEncsu8Nv9lilCwpcKkxNhsC0Jy', '', '2017-10-18 14:16:14', '2017-10-18 14:16:14');

-- # Tabel structure for table `vehiculos`
DROP TABLE  IF EXISTS `vehiculos`;
CREATE TABLE `vehiculos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `placa` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marca` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modelo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anio` int(11) NOT NULL,
  `serial_motor` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serial_carro` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vehiculos_placa_unique` (`placa`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `vehiculos` (`id`, `placa`, `marca`, `modelo`, `anio`, `serial_motor`, `serial_carro`, `color`, `tipo`, `status`, `created_at`, `updated_at`) VALUES (1, 'D10SV3N', 'CHEVROLET', 'AVEO LT', 2015, 8347892364037, 'BZX78NYD89E9283', 'NEGRO', 'LIGERO', 'PREPARACION', '2017-10-15 22:10:39', '2017-10-16 01:10:55');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
