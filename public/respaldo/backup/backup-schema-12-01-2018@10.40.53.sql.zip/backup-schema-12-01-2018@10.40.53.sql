-- # A Mysql Backup System
-- # Export created: 2018/01/12 on 10:40
-- # Database : schema
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `analis_asegu`
DROP TABLE  IF EXISTS `analis_asegu`;
CREATE TABLE `analis_asegu` (
  `analista_id` int(10) unsigned NOT NULL,
  `aseguradora_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `analis_asegu_analista_id_foreign` (`analista_id`),
  KEY `analis_asegu_aseguradora_id_foreign` (`aseguradora_id`),
  CONSTRAINT `analis_asegu_analista_id_foreign` FOREIGN KEY (`analista_id`) REFERENCES `analistas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `analis_asegu_aseguradora_id_foreign` FOREIGN KEY (`aseguradora_id`) REFERENCES `aseguradoras` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `analis_asegu` (`analista_id`, `aseguradora_id`, `created_at`, `updated_at`) VALUES (1, 2, '2017-11-01 03:10:50', '2017-11-01 03:10:50'), 
(2, 2, '2017-11-14 22:41:02', '2017-11-14 22:41:02'), 
(3, 1, '2017-11-14 22:44:26', '2017-11-14 22:44:26'), 
(4, 1, '2017-11-14 22:46:11', '2017-11-14 22:46:11'), 
(5, 2, '2017-11-14 22:47:32', '2017-11-14 22:47:32');

-- # Tabel structure for table `analistas`
DROP TABLE  IF EXISTS `analistas`;
CREATE TABLE `analistas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rif` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `analistas` (`id`, `rif`, `nombre`, `apellido`, `celular`, `telefono`, `email`, `status`, `created_at`, `updated_at`) VALUES (1, 'J-20989357-2', 'OSWARD JOSÉ', 'PACHECO', '0424-3513322', '0244-3962442', 'OJPR15@GMAIL.COM', 'activo', '2017-11-01 03:10:50', '2017-11-01 03:10:50'), 
(2, 'J-10759226-4', 'ZULEIMA', 'REQUENA', '0426-4350796', '0212-4065543', 'ZULEIMA@GMAIL.COM', 'activo', '2017-11-14 22:41:01', '2017-11-14 22:41:01'), 
(3, 'J-10457682-4', 'JOSE', 'REQUENA', '0414-4911227', '0244-4562306', 'JOSENDDRB@HOTMAIL.COM', 'inactivo', '2017-11-14 22:44:26', '2017-11-14 22:44:26'), 
(4, 'J-10457682-5', 'JOSE', 'REQUENA', '0414-4911227', '0244-4562306', 'JOSENDDRB@HOTMAIL.COM', 'activo', '2017-11-14 22:46:11', '2017-11-14 22:46:11'), 
(5, 'J-23935671-2', 'PEDRO', 'FONSECA', '0414-4911227', '0212-4065543', 'PEDRO@GMAIL.COM', 'activo', '2017-11-14 22:47:32', '2017-11-14 22:47:32');

-- # Tabel structure for table `area_repues`
DROP TABLE  IF EXISTS `area_repues`;
CREATE TABLE `area_repues` (
  `area_id` int(10) unsigned NOT NULL,
  `repuesto_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `area_repues_area_id_foreign` (`area_id`),
  KEY `area_repues_repuesto_id_foreign` (`repuesto_id`),
  CONSTRAINT `area_repues_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `area_repues_repuesto_id_foreign` FOREIGN KEY (`repuesto_id`) REFERENCES `repuestos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `areas`
DROP TABLE  IF EXISTS `areas`;
CREATE TABLE `areas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `areas` (`id`, `codigo`, `descripcion`, `status`, `created_at`, `updated_at`) VALUES (1, 'A00001', 'PINTURAS', 'activo', '2017-11-17 14:07:38', '2017-11-17 14:07:38'), 
(2, 'MET0001', 'METALES', 'activo', '2017-11-17 14:12:43', '2017-11-17 14:12:43');

-- # Tabel structure for table `aseguradoras`
DROP TABLE  IF EXISTS `aseguradoras`;
CREATE TABLE `aseguradoras` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rif` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `denominacion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `aseguradoras` (`id`, `rif`, `denominacion`, `telefono`, `email`, `status`, `created_at`, `updated_at`) VALUES (1, 'J-20989357-0', 'MULTINACIONAL DE SEGUROS C.A', '0212-4065544', 'MULTISEGUROS@GMAIL.COM', 'activo', '2017-11-01 03:09:00', '2017-11-17 22:18:04'), 
(2, 'J-20989357-4', 'SEGUROS UNIVERSITAS C.A', '0212-4065338', 'SEGUROSUNIVERSITAS@GMAIL.COM', 'activo', '2017-11-01 03:09:37', '2017-11-17 22:13:56'), 
(3, 'J-20989357-8', 'SEGUROS ALTAMIRA C.A', '0212-4065329', 'SEGUROSALTA@GMAIL.COM', 'activo', '2017-11-17 05:54:56', '2017-11-28 06:53:11'), 
(4, 'J-20989357-3', 'SEGUROS CARACAS C.A', '0212-4065840', 'SEGUROSCARACAS@GMAIL.COM', 'activo', '2017-11-17 13:46:45', '2017-11-28 06:50:24'), 
(5, 'J-25873529-3', 'RWVRVR', '0212-4065333', 'YELI2@GMAIL.COM', 'inactivo', '2017-11-22 05:29:07', '2017-11-22 05:29:07'), 
(6, 'J-25873529-5', 'RWVRVR', '0212-4065333', 'YELI2@GMAIL.COM', 'inactivo', '2017-11-22 05:29:59', '2017-11-22 05:29:59'), 
(7, 'J-25873529-0', 'RWVRVR', '0212-4065333', 'YELI2@GMAIL.COM', 'inactivo', '2017-11-22 05:32:48', '2017-11-22 05:32:48'), 
(8, 'J-14560982-3', 'JBDLJBD', '0212-4065333', 'DEMO@SENDY.CO', 'inactivo', '2017-11-22 05:35:15', '2017-11-22 05:35:15'), 
(9, 'J-14560982-8', 'JBDLJBD', '0212-4065333', 'DEMO@SENDY.CO', 'inactivo', '2017-11-22 05:39:46', '2017-11-22 05:39:46'), 
(10, 'J-14560982-5', 'JBDLJBD', '0212-4065333', 'DEMO@SENDY.CO', 'inactivo', '2017-11-22 05:40:51', '2017-11-22 05:40:51'), 
(11, 'J-14560982-1', 'JBDLJBD', '0212-4065333', 'DEMO@SENDY.CO', 'inactivo', '2017-11-22 05:44:28', '2017-11-22 05:44:28'), 
(12, 'J-20989357-1', 'FTFT', '0212-4065543', 'OSWARDP_94@HOTMAIL.COM', 'inactivo', '2017-11-22 05:46:18', '2017-11-22 05:46:18'), 
(13, 'J-23435987-1', 'SEGUROS LA ORIENTAL', '0212-2098745', 'LAORIENTAL@GMAIL.COM', 'inactivo', '2017-11-27 03:11:11', '2017-11-27 03:11:11');

-- # Tabel structure for table `ayudantes`
DROP TABLE  IF EXISTS `ayudantes`;
CREATE TABLE `ayudantes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ayudantes` (`id`, `cedula`, `nombre`, `apellido`, `telefono`, `email`, `direccion`, `status`, `created_at`, `updated_at`) VALUES (1, 'V-10759226', 'RICARDO', 'MONTOYA', '0424-4413322', 'RICARDD33@GMAIL.COM', 'VALENCIA', 'activo', '2017-11-01 03:14:56', '2017-11-01 03:14:56'), 
(2, 'V-08738012', 'ENRIQUE', 'FONSECA', '0414-5435737', 'MSA@GMAIL.COM', 'CAGUA', 'activo', '2017-11-01 03:15:49', '2017-11-28 20:20:42');

-- # Tabel structure for table `citas`
DROP TABLE  IF EXISTS `citas`;
CREATE TABLE `citas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reparacion_id` int(10) unsigned NOT NULL,
  `usuario_id` int(10) unsigned NOT NULL,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `propietario_id` int(10) unsigned NOT NULL,
  `selec_dia` date NOT NULL,
  `act` enum('ASIGNADA','VENCIDA','','') COLLATE utf8mb4_unicode_ci NOT NULL,
  `estatus` enum('activo','inactivo','','') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `citas_reparacion_id_foreign` (`reparacion_id`),
  KEY `vehiculo_id` (`vehiculo_id`,`propietario_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `citas_reparacion_id_foreign` FOREIGN KEY (`reparacion_id`) REFERENCES `reparaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `citas` (`id`, `reparacion_id`, `usuario_id`, `vehiculo_id`, `propietario_id`, `selec_dia`, `act`, `estatus`, `created_at`, `updated_at`) VALUES (1, 1, 1, 1, 1, '2017-11-26', 'VENCIDA', 'activo', '2017-11-25 23:38:53', '2017-11-25 23:38:53'), 
(2, 2, 1, 2, 2, '2017-11-29', 'VENCIDA', 'activo', '2017-11-26 00:21:14', '2017-11-26 00:21:14');

-- # Tabel structure for table `corre_asegu`
DROP TABLE  IF EXISTS `corre_asegu`;
CREATE TABLE `corre_asegu` (
  `corredor_id` int(10) unsigned NOT NULL,
  `aseguradora_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `corre_asegu_corredor_id_foreign` (`corredor_id`),
  KEY `corre_asegu_aseguradora_id_foreign` (`aseguradora_id`),
  CONSTRAINT `corre_asegu_aseguradora_id_foreign` FOREIGN KEY (`aseguradora_id`) REFERENCES `aseguradoras` (`id`) ON DELETE CASCADE,
  CONSTRAINT `corre_asegu_corredor_id_foreign` FOREIGN KEY (`corredor_id`) REFERENCES `corredores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `corre_asegu` (`corredor_id`, `aseguradora_id`, `created_at`, `updated_at`) VALUES (1, 1, '2017-11-01 03:11:33', '2017-11-01 03:11:33');

-- # Tabel structure for table `corredores`
DROP TABLE  IF EXISTS `corredores`;
CREATE TABLE `corredores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `corredores` (`id`, `cedula`, `nombre`, `apellido`, `celular`, `telefono`, `email`, `status`, `created_at`, `updated_at`) VALUES (1, 'J-10759226-4', 'CARMEN', 'FIGUERA', '0424-3224353', '0212-4065543', 'CARMENFIG@GMAIL.COM', 'activo', '2017-11-01 03:11:33', '2017-11-01 03:11:33');

-- # Tabel structure for table `facturaciones`
DROP TABLE  IF EXISTS `facturaciones`;
CREATE TABLE `facturaciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reparacion_id` int(10) unsigned NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `forma_pago` enum('efectivo','deposito / transferencia') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nro_cuenta` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nro_comprobante` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `impuesto` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtot` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facturaciones_reparacion_id_foreign` (`reparacion_id`),
  CONSTRAINT `facturaciones_reparacion_id_foreign` FOREIGN KEY (`reparacion_id`) REFERENCES `reparaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `image_recs`
DROP TABLE  IF EXISTS `image_recs`;
CREATE TABLE `image_recs` (
  `imagen_id` int(10) unsigned NOT NULL,
  `recepcion_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `image_recs_imagen_id_foreign` (`imagen_id`),
  KEY `image_recs_recepcion_id_foreign` (`recepcion_id`),
  CONSTRAINT `image_recs_imagen_id_foreign` FOREIGN KEY (`imagen_id`) REFERENCES `imagenes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `image_recs_recepcion_id_foreign` FOREIGN KEY (`recepcion_id`) REFERENCES `recepciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `image_recs` (`imagen_id`, `recepcion_id`, `created_at`, `updated_at`) VALUES (1, 1, '2017-11-26 00:38:53', '2017-11-26 00:38:53'), 
(2, 1, '2017-11-26 00:38:53', '2017-11-26 00:38:53'), 
(3, 1, '2017-11-26 00:38:54', '2017-11-26 00:38:54'), 
(4, 1, '2017-11-26 00:38:54', '2017-11-26 00:38:54'), 
(5, 1, '2017-11-26 00:38:54', '2017-11-26 00:38:54'), 
(6, 1, '2017-11-26 00:38:54', '2017-11-26 00:38:54'), 
(43, 2, '2017-11-29 01:47:29', '2017-11-29 01:47:29'), 
(44, 2, '2017-11-29 01:47:29', '2017-11-29 01:47:29'), 
(45, 2, '2017-11-29 01:47:30', '2017-11-29 01:47:30'), 
(46, 2, '2017-11-29 01:47:31', '2017-11-29 01:47:31'), 
(47, 2, '2017-11-29 01:47:31', '2017-11-29 01:47:31'), 
(48, 2, '2017-11-29 01:47:31', '2017-11-29 01:47:31');

-- # Tabel structure for table `image_reps`
DROP TABLE  IF EXISTS `image_reps`;
CREATE TABLE `image_reps` (
  `imagen_id` int(10) unsigned NOT NULL,
  `repuesto_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `image_reps_imagen_id_foreign` (`imagen_id`),
  KEY `image_reps_repuesto_id_foreign` (`repuesto_id`),
  CONSTRAINT `image_reps_imagen_id_foreign` FOREIGN KEY (`imagen_id`) REFERENCES `imagenes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `image_reps_repuesto_id_foreign` FOREIGN KEY (`repuesto_id`) REFERENCES `repuestos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `image_revs`
DROP TABLE  IF EXISTS `image_revs`;
CREATE TABLE `image_revs` (
  `imagen_id` int(10) unsigned NOT NULL,
  `revision_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `image_revs_imagen_id_foreign` (`imagen_id`),
  KEY `image_revs_revision_id_foreign` (`revision_id`),
  CONSTRAINT `image_revs_imagen_id_foreign` FOREIGN KEY (`imagen_id`) REFERENCES `imagenes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `image_revs_revision_id_foreign` FOREIGN KEY (`revision_id`) REFERENCES `revisiones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `image_revs` (`imagen_id`, `revision_id`, `created_at`, `updated_at`) VALUES (7, 1, '2017-11-28 05:39:39', '2017-11-28 05:39:39'), 
(8, 1, '2017-11-28 05:39:39', '2017-11-28 05:39:39'), 
(9, 1, '2017-11-28 05:39:39', '2017-11-28 05:39:39'), 
(10, 1, '2017-11-28 05:39:40', '2017-11-28 05:39:40'), 
(11, 1, '2017-11-28 05:39:40', '2017-11-28 05:39:40'), 
(12, 1, '2017-11-28 05:39:40', '2017-11-28 05:39:40'), 
(13, 2, '2017-11-28 05:40:52', '2017-11-28 05:40:52'), 
(14, 2, '2017-11-28 05:40:53', '2017-11-28 05:40:53'), 
(15, 2, '2017-11-28 05:40:53', '2017-11-28 05:40:53'), 
(16, 2, '2017-11-28 05:40:53', '2017-11-28 05:40:53'), 
(17, 2, '2017-11-28 05:40:54', '2017-11-28 05:40:54'), 
(18, 2, '2017-11-28 05:40:54', '2017-11-28 05:40:54'), 
(19, 3, '2017-11-28 05:42:32', '2017-11-28 05:42:32'), 
(20, 3, '2017-11-28 05:42:32', '2017-11-28 05:42:32'), 
(21, 3, '2017-11-28 05:42:33', '2017-11-28 05:42:33'), 
(22, 3, '2017-11-28 05:42:33', '2017-11-28 05:42:33'), 
(23, 3, '2017-11-28 05:42:34', '2017-11-28 05:42:34'), 
(24, 3, '2017-11-28 05:42:34', '2017-11-28 05:42:34'), 
(25, 4, '2017-11-28 05:46:55', '2017-11-28 05:46:55'), 
(26, 4, '2017-11-28 05:46:55', '2017-11-28 05:46:55'), 
(27, 4, '2017-11-28 05:46:56', '2017-11-28 05:46:56'), 
(28, 4, '2017-11-28 05:46:56', '2017-11-28 05:46:56'), 
(29, 5, '2017-11-28 05:48:05', '2017-11-28 05:48:05'), 
(30, 5, '2017-11-28 05:48:05', '2017-11-28 05:48:05'), 
(31, 5, '2017-11-28 05:48:06', '2017-11-28 05:48:06'), 
(32, 5, '2017-11-28 05:48:06', '2017-11-28 05:48:06'), 
(33, 5, '2017-11-28 05:48:06', '2017-11-28 05:48:06'), 
(34, 6, '2017-11-28 05:49:09', '2017-11-28 05:49:09'), 
(35, 6, '2017-11-28 05:49:09', '2017-11-28 05:49:09'), 
(36, 6, '2017-11-28 05:49:10', '2017-11-28 05:49:10'), 
(37, 6, '2017-11-28 05:49:10', '2017-11-28 05:49:10'), 
(38, 6, '2017-11-28 05:49:10', '2017-11-28 05:49:10'), 
(39, 7, '2017-11-28 21:15:44', '2017-11-28 21:15:44'), 
(40, 7, '2017-11-28 21:15:44', '2017-11-28 21:15:44'), 
(41, 7, '2017-11-28 21:15:45', '2017-11-28 21:15:45'), 
(42, 7, '2017-11-28 21:15:45', '2017-11-28 21:15:45');

-- # Tabel structure for table `imagenes`
DROP TABLE  IF EXISTS `imagenes`;
CREATE TABLE `imagenes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `imagenes` (`id`, `nombre`, `created_at`, `updated_at`) VALUES (1, 'S4onM.jpg', '2017-11-26 00:38:53', '2017-11-26 00:38:53'), 
(2, 'PCLJw.jpg', '2017-11-26 00:38:53', '2017-11-26 00:38:53'), 
(3, 'pUYy4.jpg', '2017-11-26 00:38:54', '2017-11-26 00:38:54'), 
(4, 'Ue81J.jpg', '2017-11-26 00:38:54', '2017-11-26 00:38:54'), 
(5, 'KPddc.jpg', '2017-11-26 00:38:54', '2017-11-26 00:38:54'), 
(6, 'Sq8yK.jpg', '2017-11-26 00:38:54', '2017-11-26 00:38:54'), 
(7, 'Ub3rI.jpg', '2017-11-28 05:39:39', '2017-11-28 05:39:39'), 
(8, '9LUO7.jpg', '2017-11-28 05:39:39', '2017-11-28 05:39:39'), 
(9, '6yVTs.jpg', '2017-11-28 05:39:39', '2017-11-28 05:39:39'), 
(10, 'Ltaxi.jpg', '2017-11-28 05:39:40', '2017-11-28 05:39:40'), 
(11, 'YEqEo.jpg', '2017-11-28 05:39:40', '2017-11-28 05:39:40'), 
(12, 'TzVbd.jpg', '2017-11-28 05:39:40', '2017-11-28 05:39:40'), 
(13, 'lHgRB.jpg', '2017-11-28 05:40:52', '2017-11-28 05:40:52'), 
(14, 'yzpVR.jpg', '2017-11-28 05:40:52', '2017-11-28 05:40:52'), 
(15, 'crSSu.jpg', '2017-11-28 05:40:53', '2017-11-28 05:40:53'), 
(16, 'LF2Tl.jpg', '2017-11-28 05:40:53', '2017-11-28 05:40:53'), 
(17, 'dxyI1.jpg', '2017-11-28 05:40:53', '2017-11-28 05:40:53'), 
(18, 'i2fVY.jpg', '2017-11-28 05:40:54', '2017-11-28 05:40:54'), 
(19, '330fu.jpg', '2017-11-28 05:42:32', '2017-11-28 05:42:32'), 
(20, 'LrjNb.jpg', '2017-11-28 05:42:32', '2017-11-28 05:42:32'), 
(21, '0pJB5.jpg', '2017-11-28 05:42:32', '2017-11-28 05:42:32'), 
(22, 'V0B6Z.jpg', '2017-11-28 05:42:33', '2017-11-28 05:42:33'), 
(23, 'lpLRS.jpg', '2017-11-28 05:42:34', '2017-11-28 05:42:34'), 
(24, '733iY.jpg', '2017-11-28 05:42:34', '2017-11-28 05:42:34'), 
(25, 'pE9gK.jpg', '2017-11-28 05:46:54', '2017-11-28 05:46:54'), 
(26, 'tL2MR.jpg', '2017-11-28 05:46:55', '2017-11-28 05:46:55'), 
(27, 'ZdRDC.jpg', '2017-11-28 05:46:56', '2017-11-28 05:46:56'), 
(28, 'wsaJC.jpg', '2017-11-28 05:46:56', '2017-11-28 05:46:56'), 
(29, 'lH4op.jpg', '2017-11-28 05:48:05', '2017-11-28 05:48:05'), 
(30, 'ZaZru.jpg', '2017-11-28 05:48:05', '2017-11-28 05:48:05'), 
(31, '6aLAj.jpg', '2017-11-28 05:48:05', '2017-11-28 05:48:05'), 
(32, 'X2TT1.jpg', '2017-11-28 05:48:06', '2017-11-28 05:48:06'), 
(33, 'GqlpI.jpg', '2017-11-28 05:48:06', '2017-11-28 05:48:06'), 
(34, 'J7Unb.jpg', '2017-11-28 05:49:08', '2017-11-28 05:49:08'), 
(35, 'wzOpz.jpg', '2017-11-28 05:49:09', '2017-11-28 05:49:09'), 
(36, 'e20gS.jpg', '2017-11-28 05:49:10', '2017-11-28 05:49:10'), 
(37, 'R7O5n.jpg', '2017-11-28 05:49:10', '2017-11-28 05:49:10'), 
(38, '0gUJ3.jpg', '2017-11-28 05:49:10', '2017-11-28 05:49:10'), 
(39, 'taeoS.jpg', '2017-11-28 21:15:44', '2017-11-28 21:15:44'), 
(40, '99Sn0.jpg', '2017-11-28 21:15:44', '2017-11-28 21:15:44'), 
(41, '5O7HZ.jpg', '2017-11-28 21:15:45', '2017-11-28 21:15:45'), 
(42, '6LEUv.jpg', '2017-11-28 21:15:45', '2017-11-28 21:15:45'), 
(43, '9MBY0.jpg', '2017-11-29 01:47:29', '2017-11-29 01:47:29'), 
(44, 'Om1BB.jpg', '2017-11-29 01:47:29', '2017-11-29 01:47:29'), 
(45, 'roVrH.jpg', '2017-11-29 01:47:30', '2017-11-29 01:47:30'), 
(46, 'OoHjG.jpg', '2017-11-29 01:47:30', '2017-11-29 01:47:30'), 
(47, 'qvXfn.jpg', '2017-11-29 01:47:31', '2017-11-29 01:47:31'), 
(48, 'poyVz.jpg', '2017-11-29 01:47:31', '2017-11-29 01:47:31');

-- # Tabel structure for table `jobs`
DROP TABLE  IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `migrations`
DROP TABLE  IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1, '2014_10_12_000000_create_users_table', 1), 
(2, '2014_10_12_100000_create_password_resets_table', 1), 
(3, '2017_05_08_121909_create_propietarios_table', 1), 
(4, '2017_05_08_121955_create_vehiculos_table', 1), 
(5, '2017_05_08_122044_create_repuestos_table', 1), 
(6, '2017_05_08_122108_create_aseguradoras_table', 1), 
(7, '2017_05_08_122136_create_corredores_table', 1), 
(8, '2017_05_08_123130_create_operarios_table', 1), 
(9, '2017_05_14_010822_create_analistas_table', 1), 
(10, '2017_05_14_060415_create_polizas_table', 1), 
(11, '2017_05_14_154409_create_reparaciones_table', 1), 
(12, '2017_05_14_154536_create_citas_table', 1), 
(13, '2017_05_14_154911_create_revisiones_table', 1), 
(14, '2017_05_14_154947_create_imagenes_table', 1), 
(15, '2017_05_14_155158_create_image_revs_table', 1), 
(16, '2017_05_16_132914_create_recepciones_table', 1), 
(17, '2017_05_16_133850_create_image_recs_table', 1), 
(18, '2017_05_19_005953_create_image_reps_table', 1), 
(19, '2017_05_23_050024_create_corre_asegu_table', 1), 
(20, '2017_05_23_052606_create_facturaciones_table', 1), 
(21, '2017_06_20_011033_create_analis_asegu_table', 1), 
(22, '2017_07_01_163148_create_repue_repar_table', 1), 
(23, '2017_10_13_023718_create_ayudantes_table', 1), 
(24, '2017_10_15_212721_create_areas_table', 1), 
(25, '2017_10_25_232437_create_area_repues_table', 1), 
(26, '2017_11_17_015538_create_jobs_table', 2);

-- # Tabel structure for table `operarios`
DROP TABLE  IF EXISTS `operarios`;
CREATE TABLE `operarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('latonero','pintor') COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `operarios` (`id`, `cedula`, `nombre`, `apellido`, `telefono`, `email`, `tipo`, `direccion`, `status`, `created_at`, `updated_at`) VALUES (1, 'V-10759226', 'RAFAEL', 'PEREZ', '0412-4567802', 'RAFAEL@GMAIL.COM', 'latonero', 'MARACAY', 'activo', '2017-11-01 03:12:28', '2017-11-01 03:12:28'), 
(2, 'V-20989353', 'JOSÉ', 'HERNÁNDEZ', '0426-2343567', 'JOSENDDRB@HOTMAIL.COM', 'pintor', 'MARACAY', 'activo', '2017-11-01 03:13:11', '2017-11-01 03:13:11'), 
(3, 'V-20989357', 'RW', 'WFWF', '0212-4065544', 'OJPR15@GMAIL.COM', 'pintor', 'REWFEF', 'activo', '2017-11-11 15:13:57', '2017-11-11 15:13:57');

-- # Tabel structure for table `password_resets`
DROP TABLE  IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES ('OswardP_94@hotmail.com', '$2y$10$Z/6RZsJfmlQHpt./2LrVZ.35rdv7z.6OH8nZIfZWC1lcYWeiwXN6a', '2017-11-28 05:09:55'), 
('ojpr15@gmail.com', '$2y$10$nJ47L1IvWg53UX65zyibY.redCORQHCpFdugVqTxYtEcfyz0AAsuy', '2018-01-11 04:45:02');

-- # Tabel structure for table `polizas`
DROP TABLE  IF EXISTS `polizas`;
CREATE TABLE `polizas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aseguradora_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `polizas_aseguradora_id_foreign` (`aseguradora_id`),
  CONSTRAINT `polizas_aseguradora_id_foreign` FOREIGN KEY (`aseguradora_id`) REFERENCES `aseguradoras` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `polizas` (`id`, `numero`, `aseguradora_id`, `created_at`, `updated_at`) VALUES (1, '43-43-675676', 1, '2017-11-25 21:25:55', '2017-11-25 21:25:55'), 
(2, '34-76-5365986', 2, '2017-11-26 00:19:34', '2017-11-26 00:19:34'), 
(3, '43-43-6546446', 3, '2018-01-11 05:41:44', '2018-01-11 05:41:44'), 
(4, '43-43-6546446', 3, '2018-01-11 05:43:59', '2018-01-11 05:43:59');

-- # Tabel structure for table `propietarios`
DROP TABLE  IF EXISTS `propietarios`;
CREATE TABLE `propietarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rif` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre_completo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `propietarios` (`id`, `rif`, `nombre_completo`, `telefono`, `email`, `created_at`, `updated_at`) VALUES (1, 'V-20989357', 'PACHECO REQUENA OSWARD JOSÉ', '0424-3513322', 'OJPR15@GMAIL.COM', '2017-11-25 21:25:56', '2017-11-25 21:25:56'), 
(2, 'V-24924739', 'REQUENA GONZALEZ LEONCIO ENRIQUE', '0416-2415105', 'LEO@GMAIL.COM', '2017-11-26 00:19:34', '2017-11-26 00:19:34'), 
(3, 'V-8738012', 'PACHECO MATUTE JOSÉ FÉLIX', '0412-4903039', 'PACHECOMATUTE67@GMAIL.COM', '2018-01-11 05:41:44', '2018-01-11 05:41:44'), 
(4, 'V-8738012', 'PACHECO MATUTE JOSÉ FÉLIX', '0412-4903039', 'PACHECOMATUTE67@GMAIL.COM', '2018-01-11 05:43:59', '2018-01-11 05:43:59');

-- # Tabel structure for table `recepciones`
DROP TABLE  IF EXISTS `recepciones`;
CREATE TABLE `recepciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `metodo` enum('Aseguradora','Particular','','') COLLATE utf8mb4_unicode_ci NOT NULL,
  `chofer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tlf_chofer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productor` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recibe` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `kilometraje` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `combustible` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observacion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recepciones_vehiculo_id_foreign` (`vehiculo_id`),
  CONSTRAINT `recepciones_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `recepciones` (`id`, `vehiculo_id`, `metodo`, `chofer`, `tlf_chofer`, `productor`, `recibe`, `fecha`, `kilometraje`, `combustible`, `observacion`, `created_at`, `updated_at`) VALUES (1, 1, 'Aseguradora', 'JOSE', '0414-234-9650', 'SEGUROS CARACAS', 'RAFAEL GAMBOA', '2017-11-27', '22000 KM', '12 MIL LITROS', 'NELNRF', '2017-11-26 00:38:53', '2017-11-26 00:38:53'), 
(2, 2, 'Particular', 'GUSTAVO GUEVARA', '0414-2349650', 'SEGUROS CARACAS', 'FERNANDO MORÁN', '2017-11-29', '22000 KM', '13 MIL LITROS', 'NINGUNO', '2017-11-29 01:47:29', '2017-11-29 01:47:29');

-- # Tabel structure for table `reparaciones`
DROP TABLE  IF EXISTS `reparaciones`;
CREATE TABLE `reparaciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned NOT NULL,
  `propietario_id` int(10) unsigned NOT NULL,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `poliza_id` int(10) unsigned NOT NULL,
  `analista_id` int(10) unsigned NOT NULL,
  `latonero_id` int(10) unsigned NOT NULL,
  `pintor_id` int(10) unsigned NOT NULL,
  `fecha_ocu` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `num_certificado` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nro_siniestro` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notas` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mano_obra` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `depreciacion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mecanica_otros` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtotal_mo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `otros_gastos` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tot_manobra` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_repues` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `depre_repues` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_accesorios` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `depre_acce` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `repues_taller` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `manejo_repues` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deduccion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_prepago` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `iva` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deducible_p` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtotal` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `islr` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordenes_repues` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `repues_otros` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `depreciacion_two` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accesorios` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `depreciacion_nega` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_ordenes_acc` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto_asegu` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto_final` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion_daños` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipos_daños` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `selec_repues` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_dispo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo','','') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reparaciones_propietario_id_foreign` (`propietario_id`),
  KEY `reparaciones_vehiculo_id_foreign` (`vehiculo_id`),
  KEY `reparaciones_analista_id_foreign` (`analista_id`),
  KEY `reparaciones_latonero_id_foreign` (`latonero_id`),
  KEY `reparaciones_pintor_id_foreign` (`pintor_id`),
  KEY `reparaciones_poliza_id_foreign` (`poliza_id`) USING BTREE,
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `reparaciones_analista_id_foreign` FOREIGN KEY (`analista_id`) REFERENCES `analistas` (`id`),
  CONSTRAINT `reparaciones_latonero_id_foreign` FOREIGN KEY (`latonero_id`) REFERENCES `operarios` (`id`),
  CONSTRAINT `reparaciones_pintor_id_foreign` FOREIGN KEY (`pintor_id`) REFERENCES `operarios` (`id`),
  CONSTRAINT `reparaciones_propietario_id_foreign` FOREIGN KEY (`propietario_id`) REFERENCES `propietarios` (`id`),
  CONSTRAINT `reparaciones_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `reparaciones` (`id`, `usuario_id`, `propietario_id`, `vehiculo_id`, `poliza_id`, `analista_id`, `latonero_id`, `pintor_id`, `fecha_ocu`, `num_certificado`, `nro_siniestro`, `notas`, `mano_obra`, `depreciacion`, `mecanica_otros`, `subtotal_mo`, `otros_gastos`, `tot_manobra`, `total_repues`, `depre_repues`, `total_accesorios`, `depre_acce`, `repues_taller`, `manejo_repues`, `deduccion`, `desc_prepago`, `monto`, `iva`, `deducible_p`, `subtotal`, `islr`, `ordenes_repues`, `repues_otros`, `depreciacion_two`, `accesorios`, `depreciacion_nega`, `total_ordenes_acc`, `monto_asegu`, `monto_final`, `descripcion_daños`, `tipos_daños`, `selec_repues`, `no_dispo`, `status`, `created_at`, `updated_at`) VALUES (1, 1, 1, 1, 1, 5, 1, 2, '2017-11-25', 45645645, '36-77465645', 'NINGUNA', 998, 898, 898, 898, 98, 898, 989, 98, 4565, 98, 9, 98, 98, 89, 98, 98, 8, 8, 88, 9, 898, 98, 8, 99, 98, 9, 898, 'PUERTA IZQUIERDA', 'REPARAR, PINTAR E INSTALAR', 'PUERTA ZQUIERDA', 'NO DISPONIBLE', 'activo', '2017-11-25 21:25:56', '2017-11-25 21:25:56'), 
(2, 1, 2, 2, 2, 3, 1, 2, '2017-11-26', 4369863, '36-08974245', 'NINGUNA...', 8, 78, 8787, 8, 70, 8, 7087, 7, 87, 30708, 7088, 87, 8, 8, 7, 7, 70, 8, 767, 777, 787, 9, 70, 8787, 6, 67, 767, 'BDCUIBWEBCIWCBWIEC C
ECBUCBEWBCWEC
ECBIECBEIBC', 'EBFBEWFBW
CJWEBCIBEUFD
EDEWBUWEBNCW
CWBCBWE', 'CJSDCUOBWDOCOWHCOHQOH
CBEFBEFEDWEDEBDED
EDEDBEOCHE0HC', 'EFBEBEB
EDBEONEDE+DED
EDEFBEBDE
DEBDIBEDC+EC', 'activo', '2017-11-26 00:19:34', '2017-11-26 00:19:34'), 
(3, 1, 4, 3, 4, 1, 1, 2, '2017-10-12', 544950804875, '43-9478697', 'ABECDEFGHIJKLMNÑOPQRSTUVWXYZ', 878, 897987, 987, 987, 97, 8977, 787, 987, 987, 987, 7, 987, 7, 9987, 987, 7, 79878, 7, 7, 9877, 987987, 7, 987, 87, 97897, 987, 897, 'ABECDEFGHIJKLMNÑOPQRSTUVWXYZ', 'ABECDEFGHIJKLMNÑOPQRSTUVWXYZ', 'ABECDEFGHIJKLMNÑOPQRSTUVWXYZ', 'ABECDEFGHIJKLMNÑOPQRSTUVWXYZ', 'activo', '2018-01-11 05:43:59', '2018-01-11 05:43:59');

-- # Tabel structure for table `repue_repar`
DROP TABLE  IF EXISTS `repue_repar`;
CREATE TABLE `repue_repar` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reparacion_id` int(10) unsigned NOT NULL,
  `repuesto_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `repue_repar_reparacion_id_foreign` (`reparacion_id`),
  KEY `repue_repar_repuesto_id_foreign` (`repuesto_id`),
  CONSTRAINT `repue_repar_reparacion_id_foreign` FOREIGN KEY (`reparacion_id`) REFERENCES `reparaciones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `repue_repar_repuesto_id_foreign` FOREIGN KEY (`repuesto_id`) REFERENCES `repuestos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `repuestos`
DROP TABLE  IF EXISTS `repuestos`;
CREATE TABLE `repuestos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cantidad` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marca` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modelo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `repuestos` (`id`, `codigo`, `descripcion`, `cantidad`, `marca`, `modelo`, `area`, `status`, `created_at`, `updated_at`) VALUES (1, 'PIN002', 'PINTURA SOLINTEX', 2, 'SOLINTEX', 'EN ACEITE', 'PINTURAS', 'activo', '2017-11-17 14:08:30', '2017-11-28 21:22:16'), 
(2, 'PINT001', 'PINTURAS ACRÍLICAS', '3 GALONES', 'COLONIAL', 'PREFERENCIAL', 'PINTURAS', 'activo', '2017-11-17 14:12:04', '2017-11-28 06:27:45'), 
(3, 'PARAB0001', 'PARABRISAS XORS', 1, 'DEFAULT', 'DEFAULT', 'METALES', 'activo', '2017-11-17 14:13:26', '2017-11-28 21:13:44');

-- # Tabel structure for table `revisiones`
DROP TABLE  IF EXISTS `revisiones`;
CREATE TABLE `revisiones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `encargado_entrega` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encargado_recibe` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avances` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `revisiones_vehiculo_id_foreign` (`vehiculo_id`),
  CONSTRAINT `revisiones_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `revisiones` (`id`, `vehiculo_id`, `encargado_entrega`, `encargado_recibe`, `avances`, `tipo`, `fecha`, `created_at`, `updated_at`) VALUES (1, 1, 'RICARDO', 'MANUEL', 'NINGUNA', 'DESARMADO', '2017-11-29', '2017-11-28 05:39:38', '2017-11-28 05:39:38'), 
(2, 1, 'RICARDO', 'MANUEL', 'NINGUNA', 'DESARMADO', '2017-11-29', '2017-11-28 05:40:52', '2017-11-28 05:40:52'), 
(3, 1, 'RICARDO', 'MANUEL', 'NINGUNA', 'DESARMADO', '2017-11-29', '2017-11-28 05:42:32', '2017-11-28 05:42:32'), 
(4, 1, 'MANUEL', 'RICARDO', 'FDVDF', 'LATONERIA', '2017-11-30', '2017-11-28 05:46:54', '2017-11-28 05:46:54'), 
(5, 1, 'RICARDO', 'MANUEL', 'NINGUNA', 'PREPARACION', '2017-12-01', '2017-11-28 05:48:05', '2017-11-28 05:48:05'), 
(6, 1, 'RICARDO', 'MANUEL', 'NINGUNA', 'PINTURA', '2017-12-03', '2017-11-28 05:49:08', '2017-11-28 05:49:08'), 
(7, 1, 'RICARDO', 'ENRIQUE', 'LNNOLN', 'PULITURA', '2017-12-05', '2017-11-28 21:15:44', '2017-11-28 21:15:44');

-- # Tabel structure for table `users`
DROP TABLE  IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` enum('Administrador','Empleado') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `password`, `rol`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES (1, 'Osward José', 'ojpr15@gmail.com', '$2y$10$OrEfdaqKQuFvAmr7SV1GROLLkexy3bbx1ljgsyiiZ9Gy18HI.nLey', 'Administrador', 'activo', 'RO2zCtWlueYSMLu1mi0KqRNqsgCYjk4egMg9f75SxwoN0Wu0Jpbr3oDPwnb0', '2017-11-01 02:41:20', '2017-11-25 20:02:16'), 
(2, 'José', 'OswardP_94@hotmail.com', '$2y$10$I7DGCPBg.fmH3bGLGItU..HNvVDHNFAQgMQX7hyTFrNxGwVuNBs5e', 'Empleado', 'activo', 'frzTO6XL7g83yMegrvS5gTWdyLLW2FHbpNS5BfpVRUAduzqMjmrlGYNmaKwC', '2017-11-14 23:08:46', '2017-11-28 05:09:39'), 
(3, 'Mayba', 'muzcateguiy@gmail.com', '$2y$10$e1okzK.Pkth1QxjoWlDCvez/jmMWILK9PO0B8hsQuFPAN6sr8sOOq', 'Administrador', 'activo', '', '2017-11-17 13:52:36', '2017-11-17 13:52:36');

-- # Tabel structure for table `vehiculos`
DROP TABLE  IF EXISTS `vehiculos`;
CREATE TABLE `vehiculos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `placa` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marca` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modelo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anio` int(11) NOT NULL,
  `serial_motor` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serial_carro` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vehiculos_placa_unique` (`placa`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `vehiculos` (`id`, `placa`, `marca`, `modelo`, `anio`, `serial_motor`, `serial_carro`, `color`, `tipo`, `status`, `usuario_id`, `created_at`, `updated_at`) VALUES (1, 'D7OZV3N', 'TOYOTA', 'COROLLA', 2014, 8285728945, '24XUFN04FU409', 'PLATEADO', 'LIGERO', 'PULITURA', 1, '2017-11-25 21:25:56', '2017-11-28 21:15:44'), 
(2, 'ZFU428N', 'RENAULT', 'TWINGO', 2017, 839795734987, 'YN498XY398F', 'PLATEADO', 'LIGERO', 'RECEPCION', 1, '2017-11-26 00:19:34', '2017-11-29 01:47:29'), 
(3, 'EN7D03E', 'MAZDA', 3, 2014, 897389873, 'X3N8370Z8F3F3F03', 'PLATEADO', 'LIGERO', 'NINGUNO', 1, '2018-01-11 05:43:59', '2018-01-11 05:43:59');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
