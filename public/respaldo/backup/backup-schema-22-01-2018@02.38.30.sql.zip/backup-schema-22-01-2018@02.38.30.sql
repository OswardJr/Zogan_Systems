-- # A Mysql Backup System
-- # Export created: 2018/01/22 on 02:38
-- # Database : schema
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `analis_asegu`
DROP TABLE  IF EXISTS `analis_asegu`;
CREATE TABLE `analis_asegu` (
  `analista_id` int(10) unsigned NOT NULL,
  `aseguradora_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `analis_asegu_analista_id_foreign` (`analista_id`),
  KEY `analis_asegu_aseguradora_id_foreign` (`aseguradora_id`),
  CONSTRAINT `analis_asegu_analista_id_foreign` FOREIGN KEY (`analista_id`) REFERENCES `analistas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `analis_asegu_aseguradora_id_foreign` FOREIGN KEY (`aseguradora_id`) REFERENCES `aseguradoras` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `analis_asegu` (`analista_id`, `aseguradora_id`, `created_at`, `updated_at`) VALUES (1, 2, '2017-11-01 12:10:50', '2017-11-01 12:10:50'), 
(2, 2, '2017-11-15 07:41:02', '2017-11-15 07:41:02'), 
(3, 1, '2017-11-15 07:44:26', '2017-11-15 07:44:26'), 
(4, 1, '2017-11-15 07:46:11', '2017-11-15 07:46:11'), 
(5, 2, '2017-11-15 07:47:32', '2017-11-15 07:47:32'), 
(7, 2, '2018-01-12 19:41:53', '2018-01-12 19:41:53'), 
(8, 3, '2018-01-12 19:42:02', '2018-01-12 19:42:02');

-- # Tabel structure for table `analistas`
DROP TABLE  IF EXISTS `analistas`;
CREATE TABLE `analistas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rif` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `analistas` (`id`, `rif`, `nombre`, `apellido`, `celular`, `telefono`, `email`, `status`, `created_at`, `updated_at`) VALUES (1, 'J-20989357-2', 'OSWARD JOSÉ', 'PACHECO', '0424-3513322', '0244-3962442', 'OJPR15@GMAIL.COM', 'activo', '2017-11-01 12:10:50', '2017-11-01 12:10:50'), 
(2, 'J-10759226-4', 'ZULEIMA', 'REQUENA', '0426-4350796', '0212-4065543', 'ZULEIMA@GMAIL.COM', 'activo', '2017-11-15 07:41:01', '2017-11-15 07:41:01'), 
(3, 'J-10457682-4', 'JOSE', 'REQUENA', '0414-4911227', '0244-4562306', 'JOSENDDRB@HOTMAIL.COM', 'inactivo', '2017-11-15 07:44:26', '2017-11-15 07:44:26'), 
(4, 'J-10457682-5', 'JOSE', 'REQUENA', '0414-4911227', '0244-4562306', 'JOSENDDRB@HOTMAIL.COM', 'activo', '2017-11-15 07:46:11', '2017-11-15 07:46:11'), 
(5, 'J-23935671-2', 'PEDRO', 'FONSECA', '0414-4911227', '0212-4065543', 'PEDRO@GMAIL.COM', 'activo', '2017-11-15 07:47:32', '2017-11-15 07:47:32'), 
(7, 'J-24910259-1', 'RAMON', 'HERNANDEZ', '0424-0984517', '0212-4092442', 'RAMON564@GMAIL.COM', 'activo', '2018-01-12 19:41:53', '2018-01-12 19:41:53'), 
(8, 'J-24910251-1', 'RAMON', 'HERNANDEZ', '0424-0984517', '0212-4092442', 'RAMON564@GMAIL.COM', 'inactivo', '2018-01-12 19:42:02', '2018-01-12 19:42:02');

-- # Tabel structure for table `area_repues`
DROP TABLE  IF EXISTS `area_repues`;
CREATE TABLE `area_repues` (
  `area_id` int(10) unsigned NOT NULL,
  `repuesto_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `area_repues_area_id_foreign` (`area_id`),
  KEY `area_repues_repuesto_id_foreign` (`repuesto_id`),
  CONSTRAINT `area_repues_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `area_repues_repuesto_id_foreign` FOREIGN KEY (`repuesto_id`) REFERENCES `repuestos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `areas`
DROP TABLE  IF EXISTS `areas`;
CREATE TABLE `areas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `areas` (`id`, `codigo`, `descripcion`, `status`, `created_at`, `updated_at`) VALUES (1, 'A00001', 'PINTURAS', 'activo', '2017-11-17 23:07:38', '2017-11-17 23:07:38'), 
(2, 'MET0001', 'METALES', 'activo', '2017-11-17 23:12:43', '2018-01-19 15:01:27');

-- # Tabel structure for table `aseguradoras`
DROP TABLE  IF EXISTS `aseguradoras`;
CREATE TABLE `aseguradoras` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rif` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `denominacion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `aseguradoras` (`id`, `rif`, `denominacion`, `telefono`, `email`, `status`, `created_at`, `updated_at`) VALUES (1, 'J-20989357-0', 'MULTINACIONAL DE SEGUROS C.A', '0212-4065544', 'MULTISEGUROS@GMAIL.COM', 'activo', '2017-11-01 12:09:00', '2017-11-18 07:18:04'), 
(2, 'J-20989357-4', 'SEGUROS UNIVERSITAS C.A', '0212-4065338', 'SEGUROSUNIVERSITAS@GMAIL.COM', 'activo', '2017-11-01 12:09:37', '2017-11-18 07:13:56'), 
(3, 'J-20989357-8', 'SEGUROS ALTAMIRA C.A', '0212-4065329', 'SEGUROSALTA@GMAIL.COM', 'activo', '2017-11-17 14:54:56', '2017-11-28 15:53:11'), 
(4, 'J-20989357-3', 'SEGUROS CARACAS C.A', '0212-4065840', 'SEGUROSCARACAS@GMAIL.COM', 'activo', '2017-11-17 22:46:45', '2017-11-28 15:50:24'), 
(5, 'J-25873529-3', 'RWVRVR', '0212-4065333', 'YELI2@GMAIL.COM', 'inactivo', '2017-11-22 14:29:07', '2017-11-22 14:29:07'), 
(6, 'J-25873529-5', 'RWVRVR', '0212-4065333', 'YELI2@GMAIL.COM', 'inactivo', '2017-11-22 14:29:59', '2017-11-22 14:29:59'), 
(7, 'J-25873529-0', 'RWVRVR', '0212-4065333', 'YELI2@GMAIL.COM', 'inactivo', '2017-11-22 14:32:48', '2017-11-22 14:32:48'), 
(8, 'J-14560982-3', 'JBDLJBD', '0212-4065333', 'DEMO@SENDY.CO', 'inactivo', '2017-11-22 14:35:15', '2017-11-22 14:35:15'), 
(9, 'J-14560982-8', 'JBDLJBD', '0212-4065333', 'DEMO@SENDY.CO', 'inactivo', '2017-11-22 14:39:46', '2017-11-22 14:39:46'), 
(10, 'J-14560982-5', 'JBDLJBD', '0212-4065333', 'DEMO@SENDY.CO', 'inactivo', '2017-11-22 14:40:51', '2017-11-22 14:40:51'), 
(11, 'J-14560982-1', 'JBDLJBD', '0212-4065333', 'DEMO@SENDY.CO', 'inactivo', '2017-11-22 14:44:28', '2017-11-22 14:44:28'), 
(12, 'J-20989357-1', 'FTFT', '0212-4065543', 'OSWARDP_94@HOTMAIL.COM', 'inactivo', '2017-11-22 14:46:18', '2017-11-22 14:46:18'), 
(13, 'J-23435987-1', 'SEGUROS LA ORIENTAL', '0212-2098745', 'LAORIENTAL@GMAIL.COM', 'inactivo', '2017-11-27 12:11:11', '2017-11-27 12:11:11');

-- # Tabel structure for table `ayudantes`
DROP TABLE  IF EXISTS `ayudantes`;
CREATE TABLE `ayudantes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ayudantes` (`id`, `cedula`, `nombre`, `apellido`, `telefono`, `email`, `direccion`, `status`, `created_at`, `updated_at`) VALUES (1, 'V-10759226', 'RICARDO', 'MONTOYA', '0424-4413322', 'RICARDD33@GMAIL.COM', 'VALENCIA', 'activo', '2017-11-01 12:14:56', '2017-11-01 12:14:56'), 
(2, 'V-08738012', 'ENRIQUE', 'FONSECA', '0414-5435737', 'MSA@GMAIL.COM', 'CAGUA', 'activo', '2017-11-01 12:15:49', '2017-11-29 05:20:42'), 
(3, 'V-25924739', 'LEONCIO', 'REQUENA', '0243-4538310', 'LEOREQUENA@HOTMAIL.COM', 'LA VICTORIA', 'activo', '2018-01-12 19:45:07', '2018-01-12 19:45:07');

-- # Tabel structure for table `bitacora`
DROP TABLE  IF EXISTS `bitacora`;
CREATE TABLE `bitacora` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usu` int(11) DEFAULT NULL,
  `nom_usu` varchar(30) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `ip` varchar(30) DEFAULT NULL,
  `accion` text,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=latin1;

INSERT INTO `bitacora` (`id`, `id_usu`, `nom_usu`, `fecha`, `hora`, `ip`, `accion`, `timestamp`) VALUES (1, 1, 'Osward José', '2018-01-22', '09:23:40', '::1', 'Accedió a la bitacora', '2018-01-22 08:53:40'), 
(2, 1, 'Osward José', '2018-01-22', '09:23:50', '::1', 'Accedió al listado de ordenes de reparación', '2018-01-22 08:53:50'), 
(3, 1, 'Osward José', '2018-01-22', '09:28:49', '::1', 'Accedió a la bitacora', '2018-01-22 08:58:49'), 
(4, 1, 'Osward José', '2018-01-22', '09:28:53', '::1', 'Accedió al listado de ordenes de reparación', '2018-01-22 08:58:53'), 
(5, 1, 'Osward José', '2018-01-22', '09:28:59', '::1', 'Accedió a la bitacora', '2018-01-22 08:58:59'), 
(6, 1, 'Osward José', '2018-01-22', '09:30:21', '::1', 'Accedió al listado de ordenes de reparación', '2018-01-22 09:00:21'), 
(7, 1, 'Osward José', '2018-01-22', '09:30:27', '127.0.0.1', 'Accedió a la bitacora', '2018-01-22 09:00:27'), 
(8, 1, 'Osward José', '2018-01-22', '09:31:02', '127.0.0.1', 'Accedió al listado de usuarios', '2018-01-22 09:01:02'), 
(9, 1, 'Osward José', '2018-01-22', '09:31:15', '127.0.0.1', 'Accedió al listado de usuarios', '2018-01-22 09:01:15'), 
(10, 1, 'Osward José', '2018-01-22', '09:35:09', '127.0.0.1', 'Accedió al listado de aseguradoras', '2018-01-22 09:05:09'), 
(11, 1, 'Osward José', '2018-01-22', '09:38:59', '127.0.0.1', 'Accedió al listado de aseguradoras', '2018-01-22 09:08:59'), 
(12, 1, 'Osward José', '2018-01-22', '09:39:59', '127.0.0.1', 'Accedió al listado de usuarios', '2018-01-22 09:09:59'), 
(13, 1, 'Osward José', '2018-01-22', '09:40:11', '127.0.0.1', 'Accedió al listado de ordenes de reparación', '2018-01-22 09:10:11'), 
(14, 1, 'Osward José', '2018-01-22', '09:40:17', '127.0.0.1', 'Accedió a crear una orden de reparación', '2018-01-22 09:10:17'), 
(15, 1, 'Osward José', '2018-01-22', '09:46:27', '127.0.0.1', 'Registró una nueva orden de reparación  codigo: 3', '2018-01-22 09:16:27'), 
(16, 1, 'Osward José', '2018-01-22', '09:46:28', '127.0.0.1', 'Accedió al listado de ordenes de reparación', '2018-01-22 09:16:28'), 
(17, 1, 'Osward José', '2018-01-22', '09:52:33', '127.0.0.1', 'Accedió al listado de ordenes de reparación', '2018-01-22 09:22:33'), 
(18, 1, 'Osward José', '2018-01-22', '09:53:28', '127.0.0.1', 'Accedió a crear una orden de reparación', '2018-01-22 09:23:28'), 
(19, 1, 'Osward José', '2018-01-22', '09:59:58', '127.0.0.1', 'Registró una nueva orden de reparación  codigo: 1', '2018-01-22 09:29:58'), 
(20, 1, 'Osward José', '2018-01-22', '09:59:59', '127.0.0.1', 'Accedió al listado de ordenes de reparación', '2018-01-22 09:29:59'), 
(21, 1, 'Osward José', '2018-01-22', '10:11:22', '127.0.0.1', 'Accedió a crear una orden de reparación', '2018-01-22 09:41:22'), 
(22, 1, 'Osward José', '2018-01-22', '10:20:56', '127.0.0.1', 'Registró una nueva orden de reparación  codigo: 2', '2018-01-22 09:50:56'), 
(23, 1, 'Osward José', '2018-01-22', '10:20:56', '127.0.0.1', 'Accedió al listado de ordenes de reparación', '2018-01-22 09:50:56'), 
(24, 1, 'Osward José', '2018-01-22', '10:24:35', '127.0.0.1', 'Accedió a crear una orden de reparación', '2018-01-22 09:54:35'), 
(25, 1, 'Osward José', '2018-01-22', '10:30:14', '127.0.0.1', 'Registró una nueva orden de reparación  codigo: 3', '2018-01-22 10:00:14'), 
(26, 1, 'Osward José', '2018-01-22', '10:30:14', '127.0.0.1', 'Accedió al listado de ordenes de reparación', '2018-01-22 10:00:14'), 
(27, 1, 'Osward José', '2018-01-22', '10:33:36', '127.0.0.1', 'Accedió al listado de citas', '2018-01-22 10:03:36'), 
(28, 1, 'Osward José', '2018-01-22', '10:33:40', '127.0.0.1', 'Accedió a crear una cita', '2018-01-22 10:03:40'), 
(29, 1, 'Osward José', '2018-01-22', '10:34:12', '127.0.0.1', 'Registró una cita Orden:3', '2018-01-22 10:04:12'), 
(30, 1, 'Osward José', '2018-01-22', '10:34:12', '127.0.0.1', 'Accedió al listado de citas', '2018-01-22 10:04:12'), 
(31, 1, 'Osward José', '2018-01-22', '10:34:22', '127.0.0.1', 'Accedió al listado de citas', '2018-01-22 10:04:22'), 
(32, 1, 'Osward José', '2018-01-22', '10:34:28', '127.0.0.1', 'Accedió a crear una cita', '2018-01-22 10:04:28'), 
(33, 1, 'Osward José', '2018-01-22', '10:34:49', '127.0.0.1', 'Accedió a crear una cita', '2018-01-22 10:04:49'), 
(34, 1, 'Osward José', '2018-01-22', '10:37:57', '127.0.0.1', 'Accedió al modulo de respaldo', '2018-01-22 10:07:57'), 
(35, 1, 'Osward José', '2018-01-22', '10:38:09', '127.0.0.1', 'Accedió al modulo de respaldo', '2018-01-22 10:08:09'), 
(36, 1, 'Osward José', '2018-01-22', '10:38:38', '127.0.0.1', 'Accedió al listado de usuarios', '2018-01-22 10:08:38'), 
(37, 1, 'Osward José', '2018-01-22', '10:43:14', '127.0.0.1', 'Accedió al realizar una revision', '2018-01-22 10:13:14'), 
(38, 1, 'Osward José', '2018-01-22', '10:43:57', '127.0.0.1', 'Accedió al realizar una revision', '2018-01-22 10:13:57'), 
(39, 1, 'Osward José', '2018-01-22', '11:09:46', '127.0.0.1', 'Accedió al listado de usuarios', '2018-01-22 10:39:46'), 
(40, 1, 'Osward José', '2018-01-22', '11:10:09', '127.0.0.1', 'Accedió al listado de usuarios', '2018-01-22 10:40:09'), 
(41, 1, 'Osward José', '2018-01-22', '11:10:21', '127.0.0.1', 'Accedió al listado de ordenes de reparación', '2018-01-22 10:40:21'), 
(42, 1, 'Osward José', '2018-01-22', '11:10:24', '127.0.0.1', 'Accedió a crear una orden de reparación', '2018-01-22 10:40:24'), 
(43, 1, 'Osward José', '2018-01-22', '11:10:34', '127.0.0.1', 'Accedió a la bitacora', '2018-01-22 10:40:34'), 
(44, 1, 'Osward José', '2018-01-22', '11:10:54', '127.0.0.1', 'Accedió al modulo de respaldo', '2018-01-22 10:40:54'), 
(45, 1, 'Osward José', '2018-01-22', '11:11:50', '127.0.0.1', 'Accedió al listado de operarios', '2018-01-22 10:41:50'), 
(46, 1, 'Osward José', '2018-01-22', '11:12:13', '127.0.0.1', 'Actualizó un operario cedula: V-20989353', '2018-01-22 10:42:13'), 
(47, 1, 'Osward José', '2018-01-22', '11:12:14', '127.0.0.1', 'Accedió al listado de operarios', '2018-01-22 10:42:14'), 
(48, 1, 'Osward José', '2018-01-22', '11:12:42', '127.0.0.1', 'Actualizó un operario cedula: V-10759226', '2018-01-22 10:42:42'), 
(49, 1, 'Osward José', '2018-01-22', '11:12:43', '127.0.0.1', 'Accedió al listado de operarios', '2018-01-22 10:42:43'), 
(50, 1, 'Osward José', '2018-01-22', '11:13:04', '127.0.0.1', 'Accedió al listado de ordenes de reparación', '2018-01-22 10:43:04'), 
(51, 1, 'Osward José', '2018-01-22', '11:13:09', '127.0.0.1', 'Accedió a crear una orden de reparación', '2018-01-22 10:43:09'), 
(52, 1, 'Osward José', '2018-01-22', '11:13:16', '127.0.0.1', 'Accedió al listado de usuarios', '2018-01-22 10:43:16'), 
(53, 1, 'Osward José', '2018-01-22', '11:13:28', '127.0.0.1', 'Accedió al listado de usuarios', '2018-01-22 10:43:28'), 
(54, 1, 'Osward José', '2018-01-22', '11:13:34', '127.0.0.1', 'Accedió al listado de ordenes de reparación', '2018-01-22 10:43:34'), 
(55, 1, 'Osward José', '2018-01-22', '11:13:37', '127.0.0.1', 'Accedió a crear una orden de reparación', '2018-01-22 10:43:37'), 
(56, 1, 'Osward José', '2018-01-22', '11:14:38', '127.0.0.1', 'Accedió al listado de citas', '2018-01-22 10:44:38'), 
(57, 1, 'Osward José', '2018-01-22', '11:14:44', '127.0.0.1', 'Accedió al listado de ordenes de reparación', '2018-01-22 10:44:44'), 
(58, 1, 'Osward José', '2018-01-22', '11:14:51', '127.0.0.1', 'Accedió al listado de citas', '2018-01-22 10:44:51'), 
(59, 1, 'Osward José', '2018-01-22', '11:14:51', '127.0.0.1', 'Accedió al listado de citas', '2018-01-22 10:44:51'), 
(60, 1, 'Osward José', '2018-01-22', '11:14:59', '127.0.0.1', 'Accedió al listado de citas', '2018-01-22 10:44:59'), 
(61, 1, 'Osward José', '2018-01-22', '11:15:04', '127.0.0.1', 'Accedió a crear una cita', '2018-01-22 10:45:04'), 
(62, 1, 'Osward José', '2018-01-22', '11:15:24', '127.0.0.1', 'Registró una cita Orden:2', '2018-01-22 10:45:24'), 
(63, 1, 'Osward José', '2018-01-22', '11:15:24', '127.0.0.1', 'Accedió al listado de citas', '2018-01-22 10:45:24'), 
(64, 1, 'Osward José', '2018-01-22', '11:15:31', '127.0.0.1', 'Accedió al listado de citas', '2018-01-22 10:45:31'), 
(65, 1, 'Osward José', '2018-01-22', '11:15:35', '127.0.0.1', 'Accedió a crear una cita', '2018-01-22 10:45:35'), 
(66, 1, 'Osward José', '2018-01-22', '11:15:57', '127.0.0.1', 'Accedió a crear una cita', '2018-01-22 10:45:57'), 
(67, 1, 'Osward José', '2018-01-22', '11:18:01', '127.0.0.1', 'Accedió al realizar una revision', '2018-01-22 10:48:01'), 
(68, 1, 'Osward José', '2018-01-22', '11:18:38', '127.0.0.1', 'Accedió al realizar una revision', '2018-01-22 10:48:38'), 
(69, 1, 'Osward José', '2018-01-22', '11:22:10', '127.0.0.1', 'Cambió su clave', '2018-01-22 10:52:10'), 
(70, 1, 'Osward José', '2018-01-22', '11:22:37', '127.0.0.1', 'Accedió a la bitacora', '2018-01-22 10:52:37'), 
(71, 1, 'Osward José', '2018-01-22', '11:22:39', '127.0.0.1', 'Accedió al listado de usuarios', '2018-01-22 10:52:39'), 
(72, 1, 'Osward José', '2018-01-22', '11:24:09', '127.0.0.1', 'Accedió al listado de usuarios', '2018-01-22 10:54:09'), 
(73, 1, 'Osward José', '2018-01-22', '11:24:13', '127.0.0.1', 'Accedió a crear un usuario', '2018-01-22 10:54:13'), 
(74, 1, 'Osward José', '2018-01-22', '02:34:29', '::1', 'Accedió a la bitacora', '2018-01-22 14:04:29'), 
(75, 1, 'Osward José', '2018-01-22', '02:34:59', '127.0.0.1', 'Accedió a la bitacora', '2018-01-22 14:04:59'), 
(76, 1, 'Osward José', '2018-01-22', '02:36:51', '127.0.0.1', 'Accedió al listado de usuarios', '2018-01-22 14:06:51'), 
(77, 1, 'Osward José', '2018-01-22', '02:37:05', '127.0.0.1', 'Accedió al listado de usuarios', '2018-01-22 14:07:05'), 
(78, 1, 'Osward José', '2018-01-22', '02:37:33', '127.0.0.1', 'Accedió al listado de ordenes de reparación', '2018-01-22 14:07:33'), 
(79, 1, 'Osward José', '2018-01-22', '02:37:36', '127.0.0.1', 'Accedió a crear una orden de reparación', '2018-01-22 14:07:36'), 
(80, 1, 'Osward José', '2018-01-22', '02:38:01', '127.0.0.1', 'Accedió al modulo de respaldo', '2018-01-22 14:08:01');

-- # Tabel structure for table `citas`
DROP TABLE  IF EXISTS `citas`;
CREATE TABLE `citas` (
  `id_` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reparacion_id` int(10) unsigned NOT NULL,
  `usuario_id` int(10) unsigned NOT NULL,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `propietario_id` int(10) unsigned NOT NULL,
  `selec_dia` date NOT NULL,
  `act` enum('ASIGNADA','VENCIDA') COLLATE utf8mb4_unicode_ci NOT NULL,
  `estatus` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_`),
  KEY `citas_reparacion_id_foreign` (`reparacion_id`),
  KEY `vehiculo_id` (`vehiculo_id`,`propietario_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `citas_reparacion_id_foreign` FOREIGN KEY (`reparacion_id`) REFERENCES `reparaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `citas` (`id_`, `reparacion_id`, `usuario_id`, `vehiculo_id`, `propietario_id`, `selec_dia`, `act`, `estatus`, `created_at`, `updated_at`) VALUES (1, 3, 1, 3, 3, '2018-01-23', 'ASIGNADA', 'inactivo', '2018-01-22 10:34:12', '2018-01-22 10:34:12'), 
(2, 2, 1, 2, 2, '2018-01-25', 'ASIGNADA', 'activo', '2018-01-22 11:15:24', '2018-01-22 11:15:24');

-- # Tabel structure for table `corre_asegu`
DROP TABLE  IF EXISTS `corre_asegu`;
CREATE TABLE `corre_asegu` (
  `corredor_id` int(10) unsigned NOT NULL,
  `aseguradora_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `corre_asegu_corredor_id_foreign` (`corredor_id`),
  KEY `corre_asegu_aseguradora_id_foreign` (`aseguradora_id`),
  CONSTRAINT `corre_asegu_aseguradora_id_foreign` FOREIGN KEY (`aseguradora_id`) REFERENCES `aseguradoras` (`id`) ON DELETE CASCADE,
  CONSTRAINT `corre_asegu_corredor_id_foreign` FOREIGN KEY (`corredor_id`) REFERENCES `corredores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `corre_asegu` (`corredor_id`, `aseguradora_id`, `created_at`, `updated_at`) VALUES (1, 1, '2017-11-01 12:11:33', '2017-11-01 12:11:33'), 
(5, 2, '2018-01-12 19:36:38', '2018-01-12 19:36:38'), 
(1, 1, '2017-11-01 12:11:33', '2017-11-01 12:11:33'), 
(5, 2, '2018-01-12 19:36:38', '2018-01-12 19:36:38');

-- # Tabel structure for table `corredores`
DROP TABLE  IF EXISTS `corredores`;
CREATE TABLE `corredores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `corredores` (`id`, `cedula`, `nombre`, `apellido`, `celular`, `telefono`, `email`, `status`, `created_at`, `updated_at`) VALUES (1, 'J-10759226-4', 'CARMEN', 'FIGUERA', '0424-3224353', '0212-4065543', 'CARMENFIG@GMAIL.COM', 'activo', '2017-11-01 12:11:33', '2017-11-01 12:11:33'), 
(5, 'J-23044561-2', 'JOSE', 'PEREZ', '0424-3532309', '0243-4538307', 'JOSENRB@HOTMAIL.COM', 'activo', '2018-01-12 19:36:38', '2018-01-12 19:36:38');

-- # Tabel structure for table `facturaciones`
DROP TABLE  IF EXISTS `facturaciones`;
CREATE TABLE `facturaciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reparacion_id` int(10) unsigned NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `forma_pago` enum('efectivo','deposito / transferencia') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nro_cuenta` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nro_comprobante` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `impuesto` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtot` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facturaciones_reparacion_id_foreign` (`reparacion_id`),
  CONSTRAINT `facturaciones_reparacion_id_foreign` FOREIGN KEY (`reparacion_id`) REFERENCES `reparaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `image_recs`
DROP TABLE  IF EXISTS `image_recs`;
CREATE TABLE `image_recs` (
  `imagen_id` int(10) unsigned NOT NULL,
  `recepcion_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `image_recs_imagen_id_foreign` (`imagen_id`),
  KEY `image_recs_recepcion_id_foreign` (`recepcion_id`),
  CONSTRAINT `image_recs_imagen_id_foreign` FOREIGN KEY (`imagen_id`) REFERENCES `imagenes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `image_recs_recepcion_id_foreign` FOREIGN KEY (`recepcion_id`) REFERENCES `recepciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `image_recs` (`imagen_id`, `recepcion_id`, `created_at`, `updated_at`) VALUES (50, 2, '2018-01-22 10:43:00', '2018-01-22 10:43:00'), 
(51, 2, '2018-01-22 10:43:01', '2018-01-22 10:43:01'), 
(52, 2, '2018-01-22 10:43:01', '2018-01-22 10:43:01'), 
(53, 2, '2018-01-22 10:43:01', '2018-01-22 10:43:01'), 
(54, 2, '2018-01-22 10:43:01', '2018-01-22 10:43:01'), 
(55, 2, '2018-01-22 10:43:01', '2018-01-22 10:43:01'), 
(66, 3, '2018-01-22 11:17:50', '2018-01-22 11:17:50'), 
(67, 3, '2018-01-22 11:17:50', '2018-01-22 11:17:50'), 
(68, 3, '2018-01-22 11:17:50', '2018-01-22 11:17:50'), 
(69, 3, '2018-01-22 11:17:50', '2018-01-22 11:17:50');

-- # Tabel structure for table `image_reps`
DROP TABLE  IF EXISTS `image_reps`;
CREATE TABLE `image_reps` (
  `imagen_id` int(10) unsigned NOT NULL,
  `repuesto_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `image_reps_imagen_id_foreign` (`imagen_id`),
  KEY `image_reps_repuesto_id_foreign` (`repuesto_id`),
  CONSTRAINT `image_reps_imagen_id_foreign` FOREIGN KEY (`imagen_id`) REFERENCES `imagenes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `image_reps_repuesto_id_foreign` FOREIGN KEY (`repuesto_id`) REFERENCES `repuestos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `image_revs`
DROP TABLE  IF EXISTS `image_revs`;
CREATE TABLE `image_revs` (
  `imagen_id` int(10) unsigned NOT NULL,
  `revision_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `image_revs_imagen_id_foreign` (`imagen_id`),
  KEY `image_revs_revision_id_foreign` (`revision_id`),
  CONSTRAINT `image_revs_imagen_id_foreign` FOREIGN KEY (`imagen_id`) REFERENCES `imagenes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `image_revs_revision_id_foreign` FOREIGN KEY (`revision_id`) REFERENCES `revisiones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `image_revs` (`imagen_id`, `revision_id`, `created_at`, `updated_at`) VALUES (56, 7, '2018-01-22 10:43:49', '2018-01-22 10:43:49'), 
(57, 7, '2018-01-22 10:43:49', '2018-01-22 10:43:49'), 
(58, 7, '2018-01-22 10:43:49', '2018-01-22 10:43:49'), 
(59, 7, '2018-01-22 10:43:50', '2018-01-22 10:43:50'), 
(60, 7, '2018-01-22 10:43:50', '2018-01-22 10:43:50'), 
(61, 7, '2018-01-22 10:43:50', '2018-01-22 10:43:50'), 
(62, 8, '2018-01-22 10:44:38', '2018-01-22 10:44:38'), 
(63, 8, '2018-01-22 10:44:38', '2018-01-22 10:44:38'), 
(64, 8, '2018-01-22 10:44:38', '2018-01-22 10:44:38'), 
(65, 8, '2018-01-22 10:44:38', '2018-01-22 10:44:38'), 
(70, 9, '2018-01-22 11:18:34', '2018-01-22 11:18:34'), 
(71, 9, '2018-01-22 11:18:34', '2018-01-22 11:18:34'), 
(72, 9, '2018-01-22 11:18:34', '2018-01-22 11:18:34'), 
(73, 9, '2018-01-22 11:18:34', '2018-01-22 11:18:34'), 
(74, 9, '2018-01-22 11:18:34', '2018-01-22 11:18:34'), 
(75, 9, '2018-01-22 11:18:34', '2018-01-22 11:18:34'), 
(76, 10, '2018-01-22 11:19:14', '2018-01-22 11:19:14'), 
(77, 10, '2018-01-22 11:19:14', '2018-01-22 11:19:14'), 
(78, 10, '2018-01-22 11:19:14', '2018-01-22 11:19:14'), 
(79, 10, '2018-01-22 11:19:14', '2018-01-22 11:19:14'), 
(80, 10, '2018-01-22 11:19:14', '2018-01-22 11:19:14'), 
(81, 10, '2018-01-22 11:19:14', '2018-01-22 11:19:14');

-- # Tabel structure for table `imagenes`
DROP TABLE  IF EXISTS `imagenes`;
CREATE TABLE `imagenes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `imagenes` (`id`, `nombre`, `created_at`, `updated_at`) VALUES (1, 'S4onM.jpg', '2017-11-26 09:38:53', '2017-11-26 09:38:53'), 
(2, 'PCLJw.jpg', '2017-11-26 09:38:53', '2017-11-26 09:38:53'), 
(3, 'pUYy4.jpg', '2017-11-26 09:38:54', '2017-11-26 09:38:54'), 
(4, 'Ue81J.jpg', '2017-11-26 09:38:54', '2017-11-26 09:38:54'), 
(5, 'KPddc.jpg', '2017-11-26 09:38:54', '2017-11-26 09:38:54'), 
(6, 'Sq8yK.jpg', '2017-11-26 09:38:54', '2017-11-26 09:38:54'), 
(7, 'Ub3rI.jpg', '2017-11-28 14:39:39', '2017-11-28 14:39:39'), 
(8, '9LUO7.jpg', '2017-11-28 14:39:39', '2017-11-28 14:39:39'), 
(9, '6yVTs.jpg', '2017-11-28 14:39:39', '2017-11-28 14:39:39'), 
(10, 'Ltaxi.jpg', '2017-11-28 14:39:40', '2017-11-28 14:39:40'), 
(11, 'YEqEo.jpg', '2017-11-28 14:39:40', '2017-11-28 14:39:40'), 
(12, 'TzVbd.jpg', '2017-11-28 14:39:40', '2017-11-28 14:39:40'), 
(13, 'lHgRB.jpg', '2017-11-28 14:40:52', '2017-11-28 14:40:52'), 
(14, 'yzpVR.jpg', '2017-11-28 14:40:52', '2017-11-28 14:40:52'), 
(15, 'crSSu.jpg', '2017-11-28 14:40:53', '2017-11-28 14:40:53'), 
(16, 'LF2Tl.jpg', '2017-11-28 14:40:53', '2017-11-28 14:40:53'), 
(17, 'dxyI1.jpg', '2017-11-28 14:40:53', '2017-11-28 14:40:53'), 
(18, 'i2fVY.jpg', '2017-11-28 14:40:54', '2017-11-28 14:40:54'), 
(19, '330fu.jpg', '2017-11-28 14:42:32', '2017-11-28 14:42:32'), 
(20, 'LrjNb.jpg', '2017-11-28 14:42:32', '2017-11-28 14:42:32'), 
(21, '0pJB5.jpg', '2017-11-28 14:42:32', '2017-11-28 14:42:32'), 
(22, 'V0B6Z.jpg', '2017-11-28 14:42:33', '2017-11-28 14:42:33'), 
(23, 'lpLRS.jpg', '2017-11-28 14:42:34', '2017-11-28 14:42:34'), 
(24, '733iY.jpg', '2017-11-28 14:42:34', '2017-11-28 14:42:34'), 
(25, 'pE9gK.jpg', '2017-11-28 14:46:54', '2017-11-28 14:46:54'), 
(26, 'tL2MR.jpg', '2017-11-28 14:46:55', '2017-11-28 14:46:55'), 
(27, 'ZdRDC.jpg', '2017-11-28 14:46:56', '2017-11-28 14:46:56'), 
(28, 'wsaJC.jpg', '2017-11-28 14:46:56', '2017-11-28 14:46:56'), 
(29, 'lH4op.jpg', '2017-11-28 14:48:05', '2017-11-28 14:48:05'), 
(30, 'ZaZru.jpg', '2017-11-28 14:48:05', '2017-11-28 14:48:05'), 
(31, '6aLAj.jpg', '2017-11-28 14:48:05', '2017-11-28 14:48:05'), 
(32, 'X2TT1.jpg', '2017-11-28 14:48:06', '2017-11-28 14:48:06'), 
(33, 'GqlpI.jpg', '2017-11-28 14:48:06', '2017-11-28 14:48:06'), 
(34, 'J7Unb.jpg', '2017-11-28 14:49:08', '2017-11-28 14:49:08'), 
(35, 'wzOpz.jpg', '2017-11-28 14:49:09', '2017-11-28 14:49:09'), 
(36, 'e20gS.jpg', '2017-11-28 14:49:10', '2017-11-28 14:49:10'), 
(37, 'R7O5n.jpg', '2017-11-28 14:49:10', '2017-11-28 14:49:10'), 
(38, '0gUJ3.jpg', '2017-11-28 14:49:10', '2017-11-28 14:49:10'), 
(39, 'taeoS.jpg', '2017-11-29 06:15:44', '2017-11-29 06:15:44'), 
(40, '99Sn0.jpg', '2017-11-29 06:15:44', '2017-11-29 06:15:44'), 
(41, '5O7HZ.jpg', '2017-11-29 06:15:45', '2017-11-29 06:15:45'), 
(42, '6LEUv.jpg', '2017-11-29 06:15:45', '2017-11-29 06:15:45'), 
(43, '9MBY0.jpg', '2017-11-29 10:47:29', '2017-11-29 10:47:29'), 
(44, 'Om1BB.jpg', '2017-11-29 10:47:29', '2017-11-29 10:47:29'), 
(45, 'roVrH.jpg', '2017-11-29 10:47:30', '2017-11-29 10:47:30'), 
(46, 'OoHjG.jpg', '2017-11-29 10:47:30', '2017-11-29 10:47:30'), 
(47, 'qvXfn.jpg', '2017-11-29 10:47:31', '2017-11-29 10:47:31'), 
(48, 'poyVz.jpg', '2017-11-29 10:47:31', '2017-11-29 10:47:31'), 
(49, 'N68NQ.jpg', '2018-01-19 05:36:54', '2018-01-19 05:36:54'), 
(50, 'y71WD.jpg', '2018-01-22 10:43:00', '2018-01-22 10:43:00'), 
(51, 'etuSJ.jpg', '2018-01-22 10:43:01', '2018-01-22 10:43:01'), 
(52, 'aO8eL.jpg', '2018-01-22 10:43:01', '2018-01-22 10:43:01'), 
(53, 'xgJi4.jpg', '2018-01-22 10:43:01', '2018-01-22 10:43:01'), 
(54, 'PtcxM.jpg', '2018-01-22 10:43:01', '2018-01-22 10:43:01'), 
(55, '6lTmD.jpg', '2018-01-22 10:43:01', '2018-01-22 10:43:01'), 
(56, '4idGi.jpg', '2018-01-22 10:43:49', '2018-01-22 10:43:49'), 
(57, 'iAdRO.jpg', '2018-01-22 10:43:49', '2018-01-22 10:43:49'), 
(58, '1J83P.jpg', '2018-01-22 10:43:49', '2018-01-22 10:43:49'), 
(59, 'IsxYA.jpg', '2018-01-22 10:43:50', '2018-01-22 10:43:50'), 
(60, 'c2PDo.jpg', '2018-01-22 10:43:50', '2018-01-22 10:43:50'), 
(61, 'km7kE.jpg', '2018-01-22 10:43:50', '2018-01-22 10:43:50'), 
(62, 'SWhZu.jpg', '2018-01-22 10:44:38', '2018-01-22 10:44:38'), 
(63, 't9agZ.jpg', '2018-01-22 10:44:38', '2018-01-22 10:44:38'), 
(64, '5mhwx.jpg', '2018-01-22 10:44:38', '2018-01-22 10:44:38'), 
(65, 'BDFnF.jpg', '2018-01-22 10:44:38', '2018-01-22 10:44:38'), 
(66, '0gDrI.jpg', '2018-01-22 11:17:49', '2018-01-22 11:17:49'), 
(67, 'YXkD8.jpg', '2018-01-22 11:17:50', '2018-01-22 11:17:50'), 
(68, 'FcIH4.jpg', '2018-01-22 11:17:50', '2018-01-22 11:17:50'), 
(69, 'bjNid.jpg', '2018-01-22 11:17:50', '2018-01-22 11:17:50'), 
(70, 'rI4Ru.jpg', '2018-01-22 11:18:34', '2018-01-22 11:18:34'), 
(71, 'feyMT.jpg', '2018-01-22 11:18:34', '2018-01-22 11:18:34'), 
(72, 'XuHFx.jpg', '2018-01-22 11:18:34', '2018-01-22 11:18:34'), 
(73, '0ODZl.jpg', '2018-01-22 11:18:34', '2018-01-22 11:18:34'), 
(74, '5Sxgk.jpg', '2018-01-22 11:18:34', '2018-01-22 11:18:34'), 
(75, 'ECcHh.jpg', '2018-01-22 11:18:34', '2018-01-22 11:18:34'), 
(76, 'ZOZ5k.jpg', '2018-01-22 11:19:14', '2018-01-22 11:19:14'), 
(77, 'vZ8ZY.jpg', '2018-01-22 11:19:14', '2018-01-22 11:19:14'), 
(78, 'hWBmz.jpg', '2018-01-22 11:19:14', '2018-01-22 11:19:14'), 
(79, 'pBazI.jpg', '2018-01-22 11:19:14', '2018-01-22 11:19:14'), 
(80, 'MhzpY.jpg', '2018-01-22 11:19:14', '2018-01-22 11:19:14'), 
(81, 'omZ6Q.jpg', '2018-01-22 11:19:14', '2018-01-22 11:19:14');

-- # Tabel structure for table `jobs`
DROP TABLE  IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `migrations`
DROP TABLE  IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `mod_usu`
DROP TABLE  IF EXISTS `mod_usu`;
CREATE TABLE `mod_usu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mod` int(11) NOT NULL,
  `id_usu` int(11) NOT NULL,
  `valor` enum('true','false') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=latin1;

INSERT INTO `mod_usu` (`id`, `id_mod`, `id_usu`, `valor`) VALUES (35, 5, 2, 'true'), 
(36, 7, 2, 'true'), 
(37, 9, 2, 'true'), 
(112, 1, 1, 'true'), 
(113, 3, 1, 'true'), 
(114, 4, 1, 'true'), 
(115, 5, 1, 'true'), 
(116, 6, 1, 'true'), 
(117, 7, 1, 'true'), 
(118, 8, 1, 'true'), 
(119, 9, 1, 'true'), 
(120, 11, 1, 'true'), 
(121, 12, 1, 'true');

-- # Tabel structure for table `modulos`
DROP TABLE  IF EXISTS `modulos`;
CREATE TABLE `modulos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `modulos` (`id`, `nombre`) VALUES (1, 'Respaldo y restauración de base de datos'), 
(2, 'Crear orden de reparación'), 
(3, 'Estadisticas'), 
(4, 'Repuestos'), 
(5, 'Otra cosa'), 
(6, 'Ruta'), 
(7, 'Citas'), 
(8, 'Bitacora'), 
(9, 'Reportes'), 
(11, 'Usuarios'), 
(12, 'Servicios');

-- # Tabel structure for table `operarios`
DROP TABLE  IF EXISTS `operarios`;
CREATE TABLE `operarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('latonero','pintor') COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `operarios` (`id`, `cedula`, `nombre`, `apellido`, `telefono`, `email`, `tipo`, `direccion`, `status`, `created_at`, `updated_at`) VALUES (1, 'V-10759226', 'RAFAEL JOSE', 'PEREZ', 04124567802, 'RAFAEL@GMAIL.COM', 'latonero', 'MARACAY', 'activo', '2017-11-01 12:12:28', '2018-01-22 11:12:42'), 
(2, 'V-20989353', 'GABRIEL', 'HERNÁNDEZ', 04262343567, 'JOSENDDRB@HOTMAIL.COM', 'pintor', 'MARACAY', 'activo', '2017-11-01 12:13:11', '2018-01-22 11:12:13'), 
(3, 'V-20989357', 'ROMEL', 'CHACON', '0212-4065544', 'ojpr15@gmail.com', 'latonero', 'REWFEF', 'activo', '2017-11-12 00:13:57', '2018-01-15 16:18:01'), 
(4, 'V-11111111', 'M', 'S', '0244-3333333', 'EDSD@FF', 'latonero', 'Q', 'inactivo', '2018-01-15 16:24:21', '2018-01-15 16:24:21');

-- # Tabel structure for table `password_resets`
DROP TABLE  IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `polizas`
DROP TABLE  IF EXISTS `polizas`;
CREATE TABLE `polizas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aseguradora_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `polizas_aseguradora_id_foreign` (`aseguradora_id`),
  CONSTRAINT `polizas_aseguradora_id_foreign` FOREIGN KEY (`aseguradora_id`) REFERENCES `aseguradoras` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `polizas` (`id`, `numero`, `aseguradora_id`, `created_at`, `updated_at`) VALUES (1, '39-10-0003239753', 2, '2018-01-22 09:59:58', '2018-01-22 09:59:58'), 
(2, '02-31-0013816836', 4, '2018-01-22 10:20:56', '2018-01-22 10:20:56'), 
(3, '37-90-0037273289', 2, '2018-01-22 10:30:13', '2018-01-22 10:30:13');

-- # Tabel structure for table `propietarios`
DROP TABLE  IF EXISTS `propietarios`;
CREATE TABLE `propietarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rif` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre_completo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `propietarios` (`id`, `rif`, `nombre_completo`, `telefono`, `email`, `created_at`, `updated_at`) VALUES (1, 'V-23401276-0', 'RENGIFO PEREZ ALFONSO EDUARDO', 04243389012, 'RENGI_76@GMAIL.COM', '2018-01-22 09:59:58', '2018-01-22 09:59:58'), 
(2, 'J-12560941-1', 'HERNANDEZ SABATIA LUIS JOSE', 04123016792, 'AMERICA1213@YAHOO.ES', '2018-01-22 10:20:56', '2018-01-22 10:20:56'), 
(3, 'V-10651902-0', 'CAMPOS SARMIENTO FRANKLIN ANTUAN', 04269807620, 'CAMPOSFRNAK@GMAIL.COM', '2018-01-22 10:30:14', '2018-01-22 10:30:14');

-- # Tabel structure for table `recepciones`
DROP TABLE  IF EXISTS `recepciones`;
CREATE TABLE `recepciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `metodo` enum('Aseguradora','Particular','','') COLLATE utf8mb4_unicode_ci NOT NULL,
  `chofer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tlf_chofer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productor` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recibe` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `kilometraje` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `combustible` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observacion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recepciones_vehiculo_id_foreign` (`vehiculo_id`),
  CONSTRAINT `recepciones_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `recepciones` (`id`, `vehiculo_id`, `metodo`, `chofer`, `tlf_chofer`, `productor`, `recibe`, `fecha`, `kilometraje`, `combustible`, `observacion`, `created_at`, `updated_at`) VALUES (1, 1, 'Aseguradora', 'JOSE', '0414-234-9650', 'SEGUROS CARACAS', 'RAFAEL GAMBOA', '2017-11-27', '22000 KM', '12 MIL LITROS', 'NELNRF', '2017-11-26 09:38:53', '2017-11-26 09:38:53'), 
(2, 3, 'Aseguradora', 'JACKSON MARCANO', 04243511904, 'SEGUROS UNIVERSITAS', 'JHOAN PEREZ', '2018-01-24', '345.689 KM', '40.000 LITROS', 'SIN NOVEDAD', '2018-01-22 10:43:00', '2018-01-22 10:43:00'), 
(3, 2, 'Aseguradora', 'LUIS', 04243516678, 'SEGUROS UNIVERSITAS', 'RAFAEL', '2018-01-30', '220.000 KM', '25.000 LTS', 'no hubo detalles', '2018-01-22 11:17:49', '2018-01-22 11:17:49');

-- # Tabel structure for table `reparaciones`
DROP TABLE  IF EXISTS `reparaciones`;
CREATE TABLE `reparaciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned NOT NULL,
  `propietario_id` int(10) unsigned NOT NULL,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `poliza_id` int(10) unsigned NOT NULL,
  `analista_id` int(10) unsigned NOT NULL,
  `latonero_id` int(10) unsigned NOT NULL,
  `pintor_id` int(10) unsigned NOT NULL,
  `fecha_ocu` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `num_certificado` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nro_siniestro` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notas` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mano_obra` double DEFAULT NULL,
  `depreciacion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mecanica_otros` double DEFAULT NULL,
  `subtotal_mo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otros_gastos` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tot_manobra` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_repues` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `depre_repues` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_accesorios` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `depre_acce` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repues_taller` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manejo_repues` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deduccion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc_prepago` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monto` double DEFAULT NULL,
  `iva` double DEFAULT NULL,
  `deducible_p` double DEFAULT NULL,
  `subtotal` double DEFAULT NULL,
  `islr` double DEFAULT NULL,
  `ordenes_repues` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repues_otros` double DEFAULT NULL,
  `depreciacion_two` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accesorios` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `depreciacion_nega` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_ordenes_acc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monto_asegu` double DEFAULT NULL,
  `monto_final` double DEFAULT NULL,
  `descripcion_daños` text COLLATE utf8mb4_unicode_ci,
  `tipos_daños` text COLLATE utf8mb4_unicode_ci,
  `selec_repues` text COLLATE utf8mb4_unicode_ci,
  `no_dispo` text COLLATE utf8mb4_unicode_ci,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reparaciones_propietario_id_foreign` (`propietario_id`),
  KEY `reparaciones_vehiculo_id_foreign` (`vehiculo_id`),
  KEY `reparaciones_analista_id_foreign` (`analista_id`),
  KEY `reparaciones_latonero_id_foreign` (`latonero_id`),
  KEY `reparaciones_pintor_id_foreign` (`pintor_id`),
  KEY `reparaciones_poliza_id_foreign` (`poliza_id`) USING BTREE,
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `reparaciones_analista_id_foreign` FOREIGN KEY (`analista_id`) REFERENCES `analistas` (`id`),
  CONSTRAINT `reparaciones_latonero_id_foreign` FOREIGN KEY (`latonero_id`) REFERENCES `operarios` (`id`),
  CONSTRAINT `reparaciones_pintor_id_foreign` FOREIGN KEY (`pintor_id`) REFERENCES `operarios` (`id`),
  CONSTRAINT `reparaciones_propietario_id_foreign` FOREIGN KEY (`propietario_id`) REFERENCES `propietarios` (`id`),
  CONSTRAINT `reparaciones_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `reparaciones` (`id`, `usuario_id`, `propietario_id`, `vehiculo_id`, `poliza_id`, `analista_id`, `latonero_id`, `pintor_id`, `fecha_ocu`, `num_certificado`, `nro_siniestro`, `notas`, `mano_obra`, `depreciacion`, `mecanica_otros`, `subtotal_mo`, `otros_gastos`, `tot_manobra`, `total_repues`, `depre_repues`, `total_accesorios`, `depre_acce`, `repues_taller`, `manejo_repues`, `deduccion`, `desc_prepago`, `monto`, `iva`, `deducible_p`, `subtotal`, `islr`, `ordenes_repues`, `repues_otros`, `depreciacion_two`, `accesorios`, `depreciacion_nega`, `total_ordenes_acc`, `monto_asegu`, `monto_final`, `descripcion_daños`, `tipos_daños`, `selec_repues`, `no_dispo`, `status`, `created_at`, `updated_at`) VALUES (1, 1, 1, 1, 1, 5, 1, 2, '2016-10-11', 78711045, '27-8649937372', 'NINGUNA', 90120, '', 4500, 94620, 12700, 107320, '', '', '', '', '', '', '', '', '', 120, 0, 107320, 0, '', '', '', '', '', '', 0, 120198.4, 'CAPO DESTROZADO', 'DESECHAR E INSTALAR UNO NUEVO', 'CAPO NUEVO', '------', 'activo', '2018-01-22 09:59:58', '2018-01-22 09:59:58'), 
(2, 1, 2, 2, 2, 7, 3, 2, '2017-05-18', 9735103645, '11-0002372873', 'NO SE MOSTRARON CAMBIOS DRÁSTICOS', 230000, '', 9000, 239000, 20000, 259000, '', '', '', '', '', '', '', '', '', 31080, 0, 259000, 0, '', '', '', '', '', '', 0, 290080, 'DAÑO EN EL GUARDAFANGO
CHOQUE ÁREA FRONTAL', 'REPARA Y PINTAR DAÑOS', 'GUARDAFANGO
PIEZAS DE LA PARTE POSTERIOR', 'TODO CORRECTO', 'activo', '2018-01-22 10:20:56', '2018-01-22 10:20:56'), 
(3, 1, 3, 3, 3, 5, 1, 2, '2016-12-08', 27897424, '10-0086283839', 'NINGUNA', 210000, '', 2340, 212340, 46000, 258340, '', '', '', '', '', '', '', '', '', 31000.8, 0, 258340, 0, '', '', '', '', '', '', 0, 289340.8, 'CHOQUE EN LA PARTE TRASERA
CHOQUE EN LA PARTE LATERAL IZQUIERDA', 'REPARA, PINTAR E INSTALAR', 'NO DISPONIBLES', 'NO DISPONIBLES', 'activo', '2018-01-22 10:30:14', '2018-01-22 10:30:14');

-- # Tabel structure for table `repue_repar`
DROP TABLE  IF EXISTS `repue_repar`;
CREATE TABLE `repue_repar` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reparacion_id` int(10) unsigned NOT NULL,
  `repuesto_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `repue_repar_reparacion_id_foreign` (`reparacion_id`),
  KEY `repue_repar_repuesto_id_foreign` (`repuesto_id`),
  CONSTRAINT `repue_repar_reparacion_id_foreign` FOREIGN KEY (`reparacion_id`) REFERENCES `reparaciones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `repue_repar_repuesto_id_foreign` FOREIGN KEY (`repuesto_id`) REFERENCES `repuestos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `repuestos`
DROP TABLE  IF EXISTS `repuestos`;
CREATE TABLE `repuestos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cantidad` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marca` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modelo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `repuestos` (`id`, `codigo`, `descripcion`, `cantidad`, `marca`, `modelo`, `area`, `status`, `created_at`, `updated_at`) VALUES (1, 'PIN002', 'PINTURA SOLINTEX', 'b', 'SOLINTEX', 'EN ACEITE', 'PINTURAS', 'activo', '2017-11-17 23:08:30', '2018-01-15 17:48:12'), 
(2, 'PINT001', 'PINTURAS ACRÍLICAS', '3 GALONES', 'COLONIAL', 'PREFERENCIAL', 'PINTURAS', 'activo', '2017-11-17 23:12:04', '2017-11-28 15:27:45'), 
(3, 'PARAB0001', 'PARABRISAS XS', 1, 'DEFAULT', 'DEFAULT', 'METALES', 'activo', '2017-11-17 23:13:26', '2018-01-19 15:01:55'), 
(4, 'MIR00001', 'GUARDAFANGO DERECHO', 2, 'ENGINE', 'SRANDARD', 'METALES', 'activo', '2018-01-19 15:22:14', '2018-01-19 15:22:14');

-- # Tabel structure for table `revisiones`
DROP TABLE  IF EXISTS `revisiones`;
CREATE TABLE `revisiones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vehiculo_id` int(10) unsigned NOT NULL,
  `encargado_entrega` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encargado_recibe` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avances` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `revisiones_vehiculo_id_foreign` (`vehiculo_id`),
  CONSTRAINT `revisiones_vehiculo_id_foreign` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `revisiones` (`id`, `vehiculo_id`, `encargado_entrega`, `encargado_recibe`, `avances`, `tipo`, `fecha`, `created_at`, `updated_at`) VALUES (1, 1, 'RICARDO', 'MANUEL', 'NINGUNA', 'DESARMADO', '2017-11-29', '2017-11-28 14:39:38', '2017-11-28 14:39:38'), 
(2, 1, 'RICARDO', 'MANUEL', 'NINGUNA', 'DESARMADO', '2017-11-29', '2017-11-28 14:40:52', '2017-11-28 14:40:52'), 
(3, 1, 'RICARDO', 'MANUEL', 'NINGUNA', 'DESARMADO', '2017-11-29', '2017-11-28 14:42:32', '2017-11-28 14:42:32'), 
(4, 1, 'MANUEL', 'RICARDO', 'FDVDF', 'LATONERIA', '2017-11-30', '2017-11-28 14:46:54', '2017-11-28 14:46:54'), 
(5, 1, 'RICARDO', 'MANUEL', 'NINGUNA', 'PREPARACION', '2017-12-01', '2017-11-28 14:48:05', '2017-11-28 14:48:05'), 
(6, 1, 'RICARDO', 'MANUEL', 'NINGUNA', 'PINTURA', '2017-12-03', '2017-11-28 14:49:08', '2017-11-28 14:49:08'), 
(7, 3, 'ENRIQUE', 'RICARDO', 'NO HUBO DETALLES', 'DESARMADO', '2018-01-25', '2018-01-22 10:43:49', '2018-01-22 10:43:49'), 
(8, 3, 'RICARDO', 'LEONCIO', 'SIN DETALLES
REPARACIÓN EXITOSA', 'ENTREGA', '2018-01-31', '2018-01-22 10:44:38', '2018-01-22 10:44:38'), 
(9, 2, 'RICARDO', 'LEONCIO', 'NINGUNO', 'PULITURA', '2018-01-31', '2018-01-22 11:18:33', '2018-01-22 11:18:33'), 
(10, 2, 'ENRIQUE', 'LEONCIO', 'SIN DETALLES', 'ENTREGA', '2018-02-07', '2018-01-22 11:19:14', '2018-01-22 11:19:14');

-- # Tabel structure for table `users`
DROP TABLE  IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `password`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES (1, 'Osward José', 'ojpr15@gmail.com', '$2y$10$49xbdUau0fjlv/.TvfPPuuOoKrXTLXagmLFUiuNvN1r6sR1mkJ2Su', 'activo', 'NtuXCM3QrIKddD3tXBJdRz51PPMg5TWrRVljRS9d2j2qQESYq6dezkFHKub1', '2018-01-18 11:21:28', '2018-01-22 14:37:04'), 
(2, 'jhonny', 'jhonnyjosearana@gmail.com', '$2y$10$bXK7S.khIWx88JG7i15.wOz9hEIcT7FNJnuOMBsZxPDhx8CXhPZ2i', 'activo', '', '2018-01-18 20:57:19', '2018-01-19 00:50:02');

-- # Tabel structure for table `vehiculos`
DROP TABLE  IF EXISTS `vehiculos`;
CREATE TABLE `vehiculos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `placa` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marca` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modelo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anio` int(11) NOT NULL,
  `serial_motor` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serial_carro` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `vehiculos` (`id`, `placa`, `marca`, `modelo`, `anio`, `serial_motor`, `serial_carro`, `color`, `tipo`, `status`, `usuario_id`, `created_at`, `updated_at`) VALUES (1, 'A13AY1D', 'Ford', 'CARGO 1721', 2006, 4742084800232733, 'XN70R73NX802', 'Azul', 'LIGERO', 'NINGUNO', 1, '2018-01-22 09:59:58', '2018-01-22 09:59:58'), 
(2, 'A64AF7O', 'Toyota', 'DYNA', 2012, 8772429396428, 'O884365B4GD83DY', 'Negro', 'MEDIANO', 'COMPLETO', 1, '2018-01-22 10:20:56', '2018-01-22 11:19:14'), 
(3, 'A29AS5G', 'Mitsubishi', 'FK', 2014, 8472432480742, 'ZNILEFUF809373BX', 'Plata', 'LIGERO', 'COMPLETO', 1, '2018-01-22 10:30:14', '2018-01-22 10:44:38');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
