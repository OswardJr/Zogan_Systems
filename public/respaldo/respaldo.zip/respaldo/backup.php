<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">

                <div class="box-header">
                    <h3 class="box-title"><strong>Respaldo de la Data</strong></h3>
                </div><!-- /.box-header -->

                <br>
 <body>
  <div class="container">

    <div id="loginbox" style="margin-top:3.5%;" class="mainbox col-md-6 col-md-offset-2 col-sm-8 col-sm-offset-2">
      <div class="panel panel-success" >
        <div class="panel-heading">
          <center><div class="panel-title"><strong>Conexión a la Base de Datos</strong></div></center>
          <!-- <div style="float:right; font-size: 80%; position: relative; top:-10px"><a href="#">Forgot password?</a></div> -->
        </div>

        <div style="padding-top:30px" class="panel-body" >
          <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
          <form action="" method="post" name="login">

            <div style="margin-bottom: 25px" class="input-group">
             <span class="input-group-addon">Usuario</span>
             <input type="text" class="form-control" name="username" placeholder="Usuario"   id="username" required="true">
           </div>

           <div style="margin-bottom: 25px" class="input-group">
            <span class="input-group-addon">Contraseña</span>
            <input type="password" class="form-control" name="password" placeholder="Contraseña"  id="password" required="true">
          </div>

          <div style="margin-bottom: 25px" class="input-group">
            <span class="input-group-addon">Base de Datos</span>
            <input type="password" class="form-control" name="bd" placeholder="Base de Datos"  id="bd" required="true">
          </div>

          <div class="input-group">

          </div>

          <div class="row">
            <div class="col-xs-offset-5 col-xs-4">
              <a data-toggle="tooltip" title="Importar" class="btn btn-ver" href="" type="submit"
               >Iniciar</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

             <br>
             <br>


            </div><!-- /.box -->
        </div><!-- /.col -->
    </div><!-- /.row -->
</section><!-- /.content -->