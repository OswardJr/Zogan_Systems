<?php
$d = new DateTime();
?>
<section class="content-header" style="padding-top: 0px;">
  <center>
    <h1>
      Respaldo de la Data
    </h1>
  </center>
</section>
<!-- Main content -->
<section class="content">
  <div class="row" style="margin-left:10%;">
    <iframe src="views/respaldo" width="90%" frameborder="0" height="800">
      <p>Your browser does not support iframes.</p>
    </iframe>
  </div>
</section>
